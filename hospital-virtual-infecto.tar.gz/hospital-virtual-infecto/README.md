# Hospital Virtual - Infectologia

Assistente local web (Next.js) que transforma texto, PDF, prints e áudio em evolução infectológica padronizada para prontuário.

**Importante:** este sistema **não substitui julgamento médico**. Sempre revise o texto gerado antes de registrar.

## Stack

- Next.js 14 (App Router)
- Anthropic SDK (`claude-sonnet-4-6`) com **prompt caching** no system prompt
- OpenAI Whisper (transcrição de áudio - opcional)
- Cookie HMAC-signed para acesso protegido por senha
- Streaming SSE da resposta

## Variáveis de ambiente

Crie `.env.local` baseado em `.env.example`:

```
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...          # opcional - habilita transcrição de áudio
APP_PASSWORD=troque-essa-senha
AUTH_COOKIE_SECRET=gere-32-bytes-aleatorios
```

Gerar um segredo:
```sh
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Se `OPENAI_API_KEY` não estiver definida, a UI de áudio fica desabilitada — texto, PDF e imagem continuam funcionando.

## Rodar

```sh
npm install
npm run dev
# http://localhost:3000
```

## Build de produção

```sh
npm run build
npm start
```

## Como funciona

1. Médico cola texto, anexa PDF/imagem e/ou grava áudio
2. Áudio é transcrito via Whisper (server-side, OpenAI)
3. Tudo é enviado ao Claude Sonnet 4.6 com o prompt-system fixo (cacheado — após o 1º request a partir do 2º recebe `cache_read_input_tokens` próximo a zero de custo)
4. Resposta volta em streaming; UI separa as duas "caixinhas" (evolução vs observações)
5. Botão "Copiar" em cada caixa

PDFs e imagens são enviados nativamente ao Claude (vision/document blocks) — sem OCR intermediário.

## Aviso de privacidade

Esta aplicação envia dados clínicos para **Anthropic** (geração) e opcionalmente para **OpenAI** (apenas áudio). Use apenas se a sua política institucional permitir.

## Deploy no GitHub

```sh
cd hospital-virtual-infecto
git remote add origin git@github.com:SEU-USUARIO/SEU-REPO.git
git push -u origin main
```

## Limitações conhecidas

- Sem histórico/persistência - cada caso é gerado uma vez e descartado ao fechar a aba
- Whisper aceita até 25 MB de áudio
- Cada arquivo limitado a 30 MB
