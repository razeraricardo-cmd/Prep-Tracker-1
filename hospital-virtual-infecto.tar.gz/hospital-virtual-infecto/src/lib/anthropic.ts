import Anthropic from '@anthropic-ai/sdk';

let cached: Anthropic | null = null;

export function getAnthropic(): Anthropic {
  if (!cached) {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error('ANTHROPIC_API_KEY ausente. Defina no .env.local antes de rodar.');
    }
    cached = new Anthropic({ apiKey });
  }
  return cached;
}

export const MODEL = 'claude-sonnet-4-6';
