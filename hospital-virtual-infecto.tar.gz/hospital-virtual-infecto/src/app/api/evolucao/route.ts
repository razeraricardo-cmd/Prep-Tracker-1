import { NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { getAnthropic, MODEL } from '@/lib/anthropic';
import { SYSTEM_PROMPT } from '@/lib/system-prompt';
import { isAuthenticated } from '@/lib/auth';

export const runtime = 'nodejs';
export const maxDuration = 300;

type ImageMediaType = 'image/jpeg' | 'image/png' | 'image/gif' | 'image/webp';

const SUPPORTED_IMAGE_TYPES: Record<string, ImageMediaType> = {
  'image/jpeg': 'image/jpeg',
  'image/jpg': 'image/jpeg',
  'image/png': 'image/png',
  'image/gif': 'image/gif',
  'image/webp': 'image/webp',
};

const MAX_FILE_BYTES = 30 * 1024 * 1024;
const MAX_TOTAL_BYTES = 60 * 1024 * 1024;

export async function POST(req: Request) {
  if (!isAuthenticated()) {
    return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 });
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: 'Form inválido.' }, { status: 400 });
  }

  const text = (form.get('text') as string | null)?.trim() ?? '';
  const audioTranscript = (form.get('audioTranscript') as string | null)?.trim() ?? '';
  const files = form.getAll('files').filter((f): f is File => f instanceof File);

  if (!text && !audioTranscript && files.length === 0) {
    return NextResponse.json(
      { error: 'Envie pelo menos um texto, transcrição ou arquivo.' },
      { status: 400 },
    );
  }

  let totalBytes = 0;
  for (const f of files) {
    if (f.size > MAX_FILE_BYTES) {
      return NextResponse.json(
        { error: `Arquivo "${f.name}" excede 30 MB.` },
        { status: 413 },
      );
    }
    totalBytes += f.size;
  }
  if (totalBytes > MAX_TOTAL_BYTES) {
    return NextResponse.json({ error: 'Tamanho total acima de 60 MB.' }, { status: 413 });
  }

  const contentBlocks: Anthropic.ContentBlockParam[] = [];
  const textParts: string[] = [];

  if (text) textParts.push(`TEXTO COLADO PELO MÉDICO:\n${text}`);
  if (audioTranscript) {
    textParts.push(`TRANSCRIÇÃO DE ÁUDIO (PODE CONTER ERROS DE RECONHECIMENTO):\n${audioTranscript}`);
  }
  if (textParts.length > 0) {
    contentBlocks.push({ type: 'text', text: textParts.join('\n\n---\n\n') });
  }

  for (const file of files) {
    const mime = (file.type || '').toLowerCase();
    const buffer = Buffer.from(await file.arrayBuffer());
    const data = buffer.toString('base64');

    if (mime === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
      contentBlocks.push({
        type: 'document',
        source: { type: 'base64', media_type: 'application/pdf', data },
      });
      continue;
    }

    const mapped = SUPPORTED_IMAGE_TYPES[mime];
    if (mapped) {
      contentBlocks.push({
        type: 'image',
        source: { type: 'base64', media_type: mapped, data },
      });
      continue;
    }

    return NextResponse.json(
      { error: `Tipo de arquivo não suportado: "${file.name}" (${mime}).` },
      { status: 415 },
    );
  }

  contentBlocks.push({
    type: 'text',
    text: 'GERE A EVOLUÇÃO INFECTOLÓGICA NO FORMATO INSTRUÍDO. ENVIE A PRIMEIRA CAIXINHA APENAS COM A EVOLUÇÃO. SE HOUVER PENDÊNCIAS OU DIVERGÊNCIAS, ACRESCENTE A SEGUNDA CAIXINHA "OBSERVAÇÕES PARA MIM - NÃO COPIAR NO PRONTUÁRIO".',
  });

  const client = getAnthropic();

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      try {
        const messageStream = client.messages.stream({
          model: MODEL,
          max_tokens: 4096,
          thinking: { type: 'adaptive' },
          output_config: { effort: 'high' },
          system: [
            {
              type: 'text',
              text: SYSTEM_PROMPT,
              cache_control: { type: 'ephemeral' },
            },
          ],
          messages: [{ role: 'user', content: contentBlocks }],
        });

        messageStream.on('text', (delta) => {
          send('delta', { text: delta });
        });

        const final = await messageStream.finalMessage();

        send('done', {
          stop_reason: final.stop_reason,
          usage: {
            input_tokens: final.usage.input_tokens,
            output_tokens: final.usage.output_tokens,
            cache_creation_input_tokens: final.usage.cache_creation_input_tokens ?? 0,
            cache_read_input_tokens: final.usage.cache_read_input_tokens ?? 0,
          },
        });
      } catch (err) {
        const message =
          err instanceof Anthropic.APIError
            ? `Anthropic ${err.status}: ${err.message}`
            : err instanceof Error
              ? err.message
              : 'Erro inesperado.';
        send('error', { message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-store, no-transform',
      Connection: 'keep-alive',
    },
  });
}
