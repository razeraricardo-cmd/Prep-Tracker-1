import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import { isAuthenticated } from '@/lib/auth';

export const runtime = 'nodejs';
export const maxDuration = 300;

const MAX_AUDIO_BYTES = 25 * 1024 * 1024;

export async function POST(req: Request) {
  if (!isAuthenticated()) {
    return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: 'OPENAI_API_KEY não configurada no servidor.' },
      { status: 503 },
    );
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: 'Form inválido.' }, { status: 400 });
  }

  const file = form.get('audio');
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'Arquivo de áudio ausente.' }, { status: 400 });
  }
  if (file.size > MAX_AUDIO_BYTES) {
    return NextResponse.json({ error: 'Áudio acima de 25 MB.' }, { status: 413 });
  }

  const openai = new OpenAI({ apiKey });

  try {
    const transcript = await openai.audio.transcriptions.create({
      file,
      model: 'whisper-1',
      language: 'pt',
      response_format: 'text',
    });
    const text = typeof transcript === 'string' ? transcript : (transcript as { text: string }).text;
    return NextResponse.json({ text });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Falha na transcrição.';
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
