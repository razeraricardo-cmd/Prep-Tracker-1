'use client';

import { useEffect, useRef, useState } from 'react';

type UsageInfo = {
  input_tokens: number;
  output_tokens: number;
  cache_creation_input_tokens: number;
  cache_read_input_tokens: number;
};

type ParsedOutput = {
  evolution: string;
  observations: string | null;
};

function parseBoxes(raw: string): ParsedOutput {
  const fences = Array.from(raw.matchAll(/```(?:[a-zA-Z]*)?\n([\s\S]*?)```/g)).map(
    (m) => m[1].trim(),
  );

  if (fences.length === 0) {
    return { evolution: raw.trim(), observations: null };
  }
  if (fences.length === 1) {
    return { evolution: fences[0], observations: null };
  }
  return { evolution: fences[0], observations: fences.slice(1).join('\n\n').trim() || null };
}

export default function EvolucaoComposer({ audioEnabled }: { audioEnabled: boolean }) {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioTranscript, setAudioTranscript] = useState('');
  const [transcribing, setTranscribing] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [streamed, setStreamed] = useState('');
  const [parsed, setParsed] = useState<ParsedOutput | null>(null);
  const [usage, setUsage] = useState<UsageInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [recording, setRecording] = useState(false);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    return () => {
      mediaRecorderRef.current?.stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  function addFiles(list: FileList | null) {
    if (!list) return;
    const next: File[] = [...files];
    for (const f of Array.from(list)) {
      if (!next.find((x) => x.name === f.name && x.size === f.size)) next.push(f);
    }
    setFiles(next);
  }

  function removeFile(idx: number) {
    setFiles(files.filter((_, i) => i !== idx));
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const file = new File([blob], `gravacao-${Date.now()}.webm`, { type: 'audio/webm' });
        setAudioFile(file);
        await transcribeFile(file);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecording(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Não foi possível acessar o microfone.');
    }
  }

  function stopRecording() {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  }

  async function transcribeFile(file: File) {
    setTranscribing(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('audio', file);
      const res = await fetch('/api/transcribe', { method: 'POST', body: fd });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || 'Falha na transcrição.');
      setAudioTranscript((prev) => (prev ? `${prev}\n\n${body.text}` : body.text));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro.');
    } finally {
      setTranscribing(false);
    }
  }

  async function generate() {
    if (!text.trim() && !audioTranscript.trim() && files.length === 0) {
      setError('Adicione texto, transcrição ou arquivo.');
      return;
    }
    setGenerating(true);
    setError(null);
    setStreamed('');
    setParsed(null);
    setUsage(null);

    try {
      const fd = new FormData();
      if (text.trim()) fd.append('text', text);
      if (audioTranscript.trim()) fd.append('audioTranscript', audioTranscript);
      for (const f of files) fd.append('files', f);

      const res = await fetch('/api/evolucao', { method: 'POST', body: fd });
      if (!res.ok || !res.body) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `HTTP ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let acc = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let separator = buffer.indexOf('\n\n');
        while (separator !== -1) {
          const rawEvent = buffer.slice(0, separator);
          buffer = buffer.slice(separator + 2);
          separator = buffer.indexOf('\n\n');

          const lines = rawEvent.split('\n');
          let eventName = 'message';
          let data = '';
          for (const line of lines) {
            if (line.startsWith('event: ')) eventName = line.slice(7).trim();
            else if (line.startsWith('data: ')) data += line.slice(6);
          }
          if (!data) continue;
          const payload = JSON.parse(data);

          if (eventName === 'delta') {
            acc += payload.text;
            setStreamed(acc);
          } else if (eventName === 'done') {
            setUsage(payload.usage);
            setParsed(parseBoxes(acc));
          } else if (eventName === 'error') {
            throw new Error(payload.message);
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro.');
    } finally {
      setGenerating(false);
    }
  }

  function reset() {
    setText('');
    setFiles([]);
    setAudioFile(null);
    setAudioTranscript('');
    setStreamed('');
    setParsed(null);
    setUsage(null);
    setError(null);
  }

  async function copy(content: string) {
    try {
      await navigator.clipboard.writeText(content);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="space-y-6">
      <section className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-5 space-y-4">
        <div>
          <label className="text-sm font-medium mb-2 block">Texto / relato</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Cole aqui o caso, evolução, prescrição, cultura ou relato..."
            rows={8}
            className="w-full bg-[var(--surface-2)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--text)] placeholder:text-[var(--text-muted)] focus:outline-none focus:border-[var(--accent)] font-mono text-sm"
          />
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">
            Arquivos (PDF / imagem)
          </label>
          <input
            type="file"
            multiple
            accept="application/pdf,image/png,image/jpeg,image/webp,image/gif"
            onChange={(e) => {
              addFiles(e.target.files);
              e.target.value = '';
            }}
            className="block w-full text-sm text-[var(--text-muted)] file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-[var(--surface-2)] file:text-[var(--text)] hover:file:bg-[#243064]"
          />
          {files.length > 0 && (
            <ul className="mt-3 space-y-1.5">
              {files.map((f, i) => (
                <li
                  key={`${f.name}-${i}`}
                  className="flex items-center justify-between text-sm bg-[var(--surface-2)] rounded-lg px-3 py-2"
                >
                  <span className="truncate mr-3">
                    {f.name}{' '}
                    <span className="text-[var(--text-muted)]">
                      ({Math.round(f.size / 1024)} KB)
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={() => removeFile(i)}
                    className="text-[var(--text-muted)] hover:text-[var(--danger)]"
                  >
                    Remover
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">
            Áudio{' '}
            <span className="text-[var(--text-muted)] font-normal">
              {audioEnabled ? '(transcrito via Whisper)' : '(desativado — sem OPENAI_API_KEY)'}
            </span>
          </label>
          {audioEnabled ? (
            <div className="flex flex-wrap gap-2 items-center">
              {!recording ? (
                <button
                  type="button"
                  onClick={startRecording}
                  disabled={transcribing}
                  className="bg-[var(--surface-2)] hover:bg-[#243064] border border-[var(--border)] rounded-xl px-4 py-2 text-sm"
                >
                  Gravar
                </button>
              ) : (
                <button
                  type="button"
                  onClick={stopRecording}
                  className="bg-[var(--danger)] hover:opacity-90 rounded-xl px-4 py-2 text-sm text-white"
                >
                  Parar gravação
                </button>
              )}
              <input
                type="file"
                accept="audio/*"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) {
                    setAudioFile(f);
                    transcribeFile(f);
                  }
                  e.target.value = '';
                }}
                className="text-sm text-[var(--text-muted)] file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-[var(--surface-2)] file:text-[var(--text)] hover:file:bg-[#243064]"
              />
              {transcribing && <span className="text-sm text-[var(--text-muted)]">Transcrevendo…</span>}
            </div>
          ) : null}
          {audioFile && (
            <p className="text-xs text-[var(--text-muted)] mt-2">
              Arquivo: {audioFile.name} ({Math.round(audioFile.size / 1024)} KB)
            </p>
          )}
          {audioTranscript && (
            <textarea
              value={audioTranscript}
              onChange={(e) => setAudioTranscript(e.target.value)}
              rows={4}
              className="mt-3 w-full bg-[var(--surface-2)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--text)] focus:outline-none focus:border-[var(--accent)] font-mono text-sm"
            />
          )}
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            type="button"
            onClick={generate}
            disabled={generating}
            className="bg-[var(--accent)] hover:bg-[#3a78ee] disabled:opacity-50 text-white font-medium rounded-xl px-5 py-3"
          >
            {generating ? 'Gerando…' : 'Gerar evolução'}
          </button>
          <button
            type="button"
            onClick={reset}
            disabled={generating}
            className="text-[var(--text-muted)] hover:text-white px-2"
          >
            Limpar
          </button>
        </div>

        {error && <p className="text-sm text-[var(--danger)]">{error}</p>}
      </section>

      {(parsed || streamed) && (
        <section className="space-y-4">
          {parsed ? (
            <>
              <OutputBox
                title="Evolução (copiar para o prontuário)"
                content={parsed.evolution}
                onCopy={() => copy(parsed.evolution)}
              />
              {parsed.observations && (
                <OutputBox
                  title="Observações para mim — NÃO copiar no prontuário"
                  content={parsed.observations}
                  onCopy={() => copy(parsed.observations!)}
                  warn
                />
              )}
            </>
          ) : (
            <OutputBox title="Gerando…" content={streamed} onCopy={() => copy(streamed)} />
          )}

          {usage && (
            <div className="text-xs text-[var(--text-muted)] flex flex-wrap gap-x-4 gap-y-1 px-1">
              <span>input: {usage.input_tokens}</span>
              <span>output: {usage.output_tokens}</span>
              <span>cache_write: {usage.cache_creation_input_tokens}</span>
              <span>cache_read: {usage.cache_read_input_tokens}</span>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

function OutputBox({
  title,
  content,
  onCopy,
  warn,
}: {
  title: string;
  content: string;
  onCopy: () => void;
  warn?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h3
          className={`text-sm font-medium ${
            warn ? 'text-[var(--danger)]' : 'text-[var(--text)]'
          }`}
        >
          {title}
        </h3>
        <button
          type="button"
          onClick={onCopy}
          className="text-xs bg-[var(--surface-2)] hover:bg-[#243064] border border-[var(--border)] rounded-lg px-3 py-1.5"
        >
          Copiar
        </button>
      </div>
      <div className="mono-box">{content}</div>
    </div>
  );
}
