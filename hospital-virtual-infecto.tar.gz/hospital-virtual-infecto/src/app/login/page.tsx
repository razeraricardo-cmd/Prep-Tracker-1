import { redirect } from 'next/navigation';
import { isAuthenticated } from '@/lib/auth';
import LoginForm from './login-form';

export const dynamic = 'force-dynamic';

export default function LoginPage({
  searchParams,
}: {
  searchParams: { from?: string };
}) {
  if (isAuthenticated()) {
    redirect(searchParams.from || '/');
  }
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-sm bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-7">
        <h1 className="text-xl font-semibold mb-1">Hospital Virtual - Infectologia</h1>
        <p className="text-sm text-[var(--text-muted)] mb-5">
          Acesso restrito.
        </p>
        <LoginForm from={searchParams.from} />
      </div>
    </main>
  );
}
