import { redirect } from 'next/navigation';
import { isAuthenticated } from '@/lib/auth';
import EvolucaoComposer from './evolucao-composer';

export const dynamic = 'force-dynamic';

export default function Home() {
  if (!isAuthenticated()) redirect('/login');

  const audioEnabled = Boolean(process.env.OPENAI_API_KEY);

  return (
    <main className="min-h-screen p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl md:text-2xl font-semibold">
              Hospital Virtual - Infectologia
            </h1>
            <p className="text-sm text-[var(--text-muted)]">
              Assistente de estruturação de evoluções.
            </p>
          </div>
          <form action="/api/logout" method="post">
            <button
              type="submit"
              className="text-sm text-[var(--text-muted)] hover:text-white"
            >
              Sair
            </button>
          </form>
        </header>
        <EvolucaoComposer audioEnabled={audioEnabled} />
      </div>
    </main>
  );
}
