"""Tela: cadastrar novo caso, padronizar exames e gerar evolucao."""
from __future__ import annotations

from datetime import date

import streamlit as st

from cockpit import antimicrobianos as atb_mod
from cockpit import anonimizar, db, evolucao, exames, llm

st.set_page_config(page_title="Novo caso", page_icon=":new:", layout="wide")
st.title("Novo caso")

TIPOS = ["Interconsulta", "Pronto-Socorro", "Hospital Virtual", "PAD/OPAT", "Ambulatorio", "Outro"]
STATUS = ["concluido", "pendente", "aguardando_exames", "revisar"]

if "novo_caso" not in st.session_state:
    st.session_state["novo_caso"] = {}

# --- Estruturacao opcional via LLM ----------------------------------------
with st.expander("Estruturar texto bruto com IA (opcional, requer chave + consentimento)"):
    st.caption(
        "Envia o texto bruto para a API da Anthropic. Os dados saem do seu computador. "
        "Use somente se a politica institucional permitir."
    )
    disponivel = llm.disponivel()
    if not disponivel:
        st.warning("Defina `ANTHROPIC_API_KEY` no .env para habilitar.")
    texto_ia = st.text_area(
        "Cole aqui o relato/transcricao", key="ia_texto", height=200, disabled=not disponivel
    )
    consente = st.checkbox(
        "Autorizo enviar este texto para a API externa.",
        key="ia_consente",
        disabled=not disponivel,
    )
    if st.button("Extrair campos via IA", disabled=not disponivel or not consente or not texto_ia.strip()):
        with st.spinner("Chamando Claude..."):
            try:
                campos = llm.extrair_campos(texto_ia, consentimento=consente)
                st.session_state["novo_caso"].update(campos)
                st.success("Campos extraidos. Confira o formulario abaixo.")
            except Exception as e:
                st.error(f"Falha: {e}")

caso = st.session_state["novo_caso"]

# --- Formulario principal ------------------------------------------------
with st.form("novo_caso_form", clear_on_submit=False):
    c1, c2, c3 = st.columns(3)
    paciente = c1.text_input("Paciente", value=caso.get("paciente", ""))
    matricula = c2.text_input("Matricula", value=caso.get("matricula", ""))
    idade = c3.text_input("Idade", value=caso.get("idade", ""))

    c4, c5, c6 = st.columns(3)
    unidade = c4.text_input("Unidade", value=caso.get("unidade", ""))
    solicitante = c5.text_input("Solicitante", value=caso.get("solicitante", ""))
    data_atend = c6.date_input("Data", value=date.today())

    c7, c8 = st.columns(2)
    tipo = c7.selectbox(
        "Tipo de atendimento",
        TIPOS,
        index=TIPOS.index(caso["tipo_atendimento"]) if caso.get("tipo_atendimento") in TIPOS else 0,
    )
    status = c8.selectbox(
        "Status", STATUS, index=STATUS.index(caso["status"]) if caso.get("status") in STATUS else 0
    )

    demanda = st.text_input("Demanda", value=caso.get("demanda", ""))
    alergias = st.text_input("Alergias", value=caso.get("alergias", ""))

    texto_bruto = st.text_area(
        "Texto bruto / relato do caso",
        value=caso.get("texto_bruto") or caso.get("hpma") or "",
        height=180,
    )

    st.subheader("Exames")
    exames_bruto = st.text_area("Cole os exames brutos (vai virar linha unica padronizada)", height=120)
    exames_padronizados = st.text_input(
        "Exames padronizados",
        value=caso.get("exames_padronizados") or exames.padronizar_exames(exames_bruto) if exames_bruto else caso.get("exames_padronizados", ""),
    )

    culturas = st.text_area("Culturas (cole resultados)", value=caso.get("culturas", ""), height=100)

    st.subheader("Antimicrobianos")
    n_atb = st.number_input(
        "Quantos antimicrobianos?", min_value=0, max_value=10, value=max(1, len(caso.get("antimicrobianos") or [])), step=1
    )
    antimicros: list[dict] = []
    for i in range(int(n_atb)):
        existente = (caso.get("antimicrobianos") or [{}] * (i + 1))[i] if i < len(caso.get("antimicrobianos") or []) else {}
        with st.container(border=True):
            st.markdown(f"**ATB #{i + 1}**")
            ca, cb, cc = st.columns([2, 1, 1])
            nome = ca.text_input("Nome", value=existente.get("nome", ""), key=f"atb_nome_{i}")
            dose = cb.text_input("Dose", value=existente.get("dose", ""), key=f"atb_dose_{i}")
            via = cc.selectbox(
                "Via",
                list(atb_mod.vias_validas()),
                index=list(atb_mod.vias_validas()).index(existente["via"]) if existente.get("via") in atb_mod.vias_validas() else 0,
                key=f"atb_via_{i}",
            )
            cd, ce, cf = st.columns([1, 1, 1])
            intervalo = cd.text_input("Intervalo", value=existente.get("intervalo", ""), key=f"atb_int_{i}")
            duracao = ce.text_input("Duracao", value=existente.get("duracao", ""), key=f"atb_dur_{i}")
            em_uso = cf.checkbox("Em uso?", value=bool(existente.get("em_uso", True)), key=f"atb_uso_{i}")
            if nome.strip():
                antimicros.append({
                    "nome": nome, "dose": dose, "via": via,
                    "intervalo": intervalo, "duracao": duracao, "em_uso": em_uso,
                })

    conduta = st.text_area("Conduta orientada (uma por linha)", value=caso.get("conduta_orientada", ""), height=120)
    pendencias = st.text_area("Pendencias / observacoes para mim (uma por linha)", value=caso.get("pendencias", ""), height=100)

    st.subheader("Produtividade")
    c10, c11, c12 = st.columns(3)
    internacao = c10.selectbox("Houve internacao?", ["indefinido", "sim", "nao"], index=0)
    valor = c11.number_input("Valor estimado (R$)", min_value=0.0, value=0.0, step=10.0)
    obs = c12.text_input("Observacoes")

    submit = st.form_submit_button("Gerar evolucao e salvar", type="primary")

if submit:
    novo = {
        "data_atendimento": data_atend.isoformat(),
        "paciente": paciente.strip() or None,
        "matricula": matricula.strip() or None,
        "idade": idade.strip() or None,
        "unidade": unidade.strip() or None,
        "solicitante": solicitante.strip() or None,
        "tipo_atendimento": tipo,
        "demanda": demanda.strip() or None,
        "alergias": alergias.strip() or None,
        "texto_bruto": texto_bruto.strip() or None,
        "antimicrobianos": antimicros,
        "culturas": culturas.strip() or None,
        "exames_padronizados": exames_padronizados.strip() or None,
        "conduta_orientada": conduta.strip() or None,
        "pendencias": pendencias.strip() or None,
        "houve_internacao": internacao,
        "status": status,
        "valor_estimado": valor or None,
        "observacoes": obs.strip() or None,
    }

    # alertas
    alertas: list[str] = []
    alertas += atb_mod.alertas_alergia(alergias, antimicros)
    alertas += atb_mod.alertas_ajuste_renal(antimicros, tfg=None)
    if alertas:
        st.warning("Alertas de seguranca:\n\n" + "\n".join(f"- {a}" for a in alertas))

    ev = evolucao.gerar_evolucao({
        **novo,
        "hpma": texto_bruto,
        "hd": None,
    })
    novo["evolucao_gerada"] = ev

    caso_id = db.insert_caso(novo)
    st.session_state["novo_caso"] = {}
    st.success(f"Caso #{caso_id} salvo.")
    st.code(ev, language="text")

    if anonimizar.deve_anonimizar():
        anon = anonimizar.anonimizar_texto(ev, paciente, matricula)
        with st.expander("Versao anonimizada (para uso fora do prontuario)"):
            st.code(anon, language="text")
