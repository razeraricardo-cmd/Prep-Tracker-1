"""Tela: exportar CSV, XLSX, TXT do dia e relatorio mensal."""
from __future__ import annotations

from datetime import date, timedelta

import streamlit as st

from cockpit import db, export, anonimizar

st.set_page_config(page_title="Exportar", page_icon=":outbox_tray:", layout="wide")
st.title("Exportar")

anon = st.checkbox(
    "Anonimizar nomes e matriculas no export",
    value=anonimizar.deve_anonimizar(),
)

aba_csv, aba_dia, aba_mes = st.tabs(["CSV / XLSX", "Evolucoes do dia (TXT)", "Relatorio mensal"])

with aba_csv:
    c1, c2 = st.columns(2)
    de = c1.date_input("De", value=date.today().replace(day=1))
    ate = c2.date_input("Ate", value=date.today())

    casos = db.list_casos(data_de=de.isoformat(), data_ate=ate.isoformat(), limit=100000)
    st.caption(f"{len(casos)} caso(s) no recorte.")

    if casos:
        st.download_button(
            "Baixar CSV",
            data=export.to_csv(casos, anon),
            file_name=export.nome_arquivo("casos", "csv"),
            mime="text/csv",
        )
        st.download_button(
            "Baixar XLSX",
            data=export.to_xlsx(casos, anon),
            file_name=export.nome_arquivo("casos", "xlsx"),
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

with aba_dia:
    dia = st.date_input("Dia", value=date.today(), key="dia_txt")
    casos = db.list_casos(data_de=dia.isoformat(), data_ate=dia.isoformat(), limit=10000)
    st.caption(f"{len(casos)} caso(s) no dia.")
    txt = export.evolucoes_do_dia(casos, anon)
    st.text_area("Pre-visualizacao", value=txt, height=400)
    st.download_button(
        "Baixar TXT",
        data=txt.encode("utf-8"),
        file_name=f"evolucoes-{dia.isoformat()}.txt",
        mime="text/plain",
    )

with aba_mes:
    mes_alvo = st.date_input("Mes", value=date.today())
    mes_str = mes_alvo.strftime("%Y-%m")
    inicio = mes_alvo.replace(day=1)
    proximo = (inicio + timedelta(days=32)).replace(day=1)
    fim = proximo - timedelta(days=1)
    casos = db.list_casos(data_de=inicio.isoformat(), data_ate=fim.isoformat(), limit=10000)
    md = export.relatorio_mensal(casos, mes_str)
    st.markdown(md)
    st.download_button(
        "Baixar Markdown",
        data=md.encode("utf-8"),
        file_name=f"relatorio-{mes_str}.md",
        mime="text/markdown",
    )
