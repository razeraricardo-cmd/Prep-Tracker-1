"""Tela: historico com filtros, edicao e regeneracao de evolucao."""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import streamlit as st

from cockpit import db, evolucao

st.set_page_config(page_title="Historico", page_icon=":books:", layout="wide")
st.title("Historico")

with st.expander("Filtros", expanded=True):
    c1, c2, c3, c4 = st.columns(4)
    data_de = c1.date_input("De", value=date.today() - timedelta(days=30))
    data_ate = c2.date_input("Ate", value=date.today())
    unidade = c3.selectbox("Unidade", [""] + db.list_unidades())
    status_f = c4.selectbox("Status", ["", "concluido", "pendente", "aguardando_exames", "revisar"])

    c5, c6 = st.columns([1, 3])
    tipo_f = c5.selectbox("Tipo", [""] + db.list_tipos())
    busca = c6.text_input("Buscar (paciente, matricula, demanda, cultura, ATB...)")

casos = db.list_casos(
    data_de=data_de.isoformat(),
    data_ate=data_ate.isoformat(),
    unidade=unidade or None,
    status=status_f or None,
    tipo_atendimento=tipo_f or None,
    busca=busca or None,
)

st.caption(f"{len(casos)} caso(s) encontrado(s).")

if casos:
    df = pd.DataFrame(casos)
    cols = [
        "id", "data_atendimento", "paciente", "matricula", "unidade",
        "tipo_atendimento", "demanda", "status", "houve_internacao", "valor_estimado",
    ]
    st.dataframe(df[cols], use_container_width=True, hide_index=True)

    ids = [c["id"] for c in casos]
    sel = st.selectbox("Selecionar caso para detalhar/editar", options=[None] + ids, format_func=lambda x: "" if x is None else f"#{x}")

    if sel:
        caso = db.get_caso(int(sel))
        if caso:
            st.subheader(f"Caso #{caso['id']}")
            st.json({k: v for k, v in caso.items() if k != "evolucao_gerada"})

            if caso.get("evolucao_gerada"):
                st.markdown("**Evolucao gerada:**")
                st.code(caso["evolucao_gerada"], language="text")

            colA, colB, colC = st.columns(3)
            if colA.button("Regerar evolucao"):
                ev = evolucao.gerar_evolucao({**caso, "hpma": caso.get("texto_bruto")})
                db.update_caso(int(sel), {"evolucao_gerada": ev})
                st.rerun()
            novo_status = colB.selectbox(
                "Atualizar status",
                ["concluido", "pendente", "aguardando_exames", "revisar"],
                index=["concluido", "pendente", "aguardando_exames", "revisar"].index(caso.get("status") or "concluido"),
                key=f"status_{sel}",
            )
            if colB.button("Salvar status"):
                db.update_caso(int(sel), {"status": novo_status})
                st.rerun()
            if colC.button(":wastebasket: APAGAR definitivamente", type="secondary"):
                if st.session_state.get(f"confirm_del_{sel}"):
                    db.delete_caso(int(sel))
                    st.success(f"Caso #{sel} apagado.")
                    st.rerun()
                else:
                    st.session_state[f"confirm_del_{sel}"] = True
                    st.warning("Clique novamente para confirmar exclusao definitiva.")
