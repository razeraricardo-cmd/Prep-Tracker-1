"""Tela: dashboard com totais e quebras."""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import streamlit as st

from cockpit import db

st.set_page_config(page_title="Dashboard", page_icon=":bar_chart:", layout="wide")
st.title("Dashboard")

hoje = date.today()
inicio_sem = hoje - timedelta(days=hoje.weekday())
inicio_mes = hoje.replace(day=1)

todos = db.list_casos(limit=10000)
if not todos:
    st.info("Nenhum caso cadastrado. Comece em **Novo caso**.")
    st.stop()

df = pd.DataFrame(todos)
df["data_atendimento"] = pd.to_datetime(df["data_atendimento"], errors="coerce").dt.date

dia = df[df["data_atendimento"] == hoje]
semana = df[df["data_atendimento"] >= inicio_sem]
mes = df[df["data_atendimento"] >= inicio_mes]
pend = df[df["status"] != "concluido"]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Hoje", len(dia))
c2.metric("Semana", len(semana))
c3.metric("Mes", len(mes))
c4.metric("Pendentes", len(pend))

st.subheader("Casos por unidade (todo periodo)")
st.bar_chart(df["unidade"].fillna("(sem unidade)").value_counts())

st.subheader("Casos por tipo de atendimento")
st.bar_chart(df["tipo_atendimento"].fillna("(sem tipo)").value_counts())

st.subheader("Casos por status")
st.bar_chart(df["status"].fillna("(sem status)").value_counts())

valor_mes = pd.to_numeric(mes["valor_estimado"], errors="coerce").fillna(0).sum()
st.metric("Valor estimado no mes", f"R$ {valor_mes:,.2f}")

st.subheader("Pendencias abertas")
if pend.empty:
    st.success("Nenhuma pendencia em aberto.")
else:
    st.dataframe(
        pend[["id", "data_atendimento", "paciente", "unidade", "demanda", "status"]],
        use_container_width=True,
        hide_index=True,
    )
