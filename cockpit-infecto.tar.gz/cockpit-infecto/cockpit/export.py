"""Exportacoes: CSV, XLSX, TXT, relatorio mensal."""
from __future__ import annotations

from datetime import date
from io import BytesIO
from pathlib import Path
from typing import Iterable

import pandas as pd

from cockpit import anonimizar


COLUNAS = [
    "id",
    "data_atendimento",
    "paciente",
    "matricula",
    "idade",
    "unidade",
    "solicitante",
    "tipo_atendimento",
    "demanda",
    "status",
    "houve_internacao",
    "valor_estimado",
    "alergias",
    "culturas",
    "exames_padronizados",
    "conduta_orientada",
    "pendencias",
    "observacoes",
]


def _normalizar(casos: Iterable[dict], anon: bool) -> pd.DataFrame:
    rows: list[dict] = []
    for c in casos:
        d = {k: c.get(k) for k in COLUNAS}
        if anon:
            d["paciente"] = anonimizar.iniciais(d.get("paciente"))
            d["matricula"] = anonimizar.mascarar_matricula(d.get("matricula"))
        rows.append(d)
    return pd.DataFrame(rows, columns=COLUNAS)


def to_csv(casos: list[dict], anon: bool) -> bytes:
    return _normalizar(casos, anon).to_csv(index=False).encode("utf-8")


def to_xlsx(casos: list[dict], anon: bool) -> bytes:
    df = _normalizar(casos, anon)
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="casos", index=False)
    return buf.getvalue()


def evolucoes_do_dia(casos: list[dict], anon: bool) -> str:
    """Concatena evolucoes geradas de uma lista de casos do mesmo dia."""
    blocos: list[str] = []
    for c in casos:
        if not c.get("evolucao_gerada"):
            continue
        ev = c["evolucao_gerada"]
        if anon:
            ev = anonimizar.anonimizar_texto(ev, c.get("paciente"), c.get("matricula"))
        cabecalho = f"### CASO #{c['id']} - {c.get('unidade') or 'unidade?'} - {c.get('demanda') or ''}"
        blocos.append(f"{cabecalho}\n\n{ev}\n")
    if not blocos:
        return "Nenhuma evolucao gerada no recorte selecionado."
    return "\n\n---\n\n".join(blocos)


def relatorio_mensal(casos: list[dict], mes: str) -> str:
    """Markdown simples com totais e quebras por unidade e tipo."""
    if not casos:
        return f"# Relatorio mensal - {mes}\n\nNenhum caso registrado."
    df = pd.DataFrame(casos)
    total = len(df)
    internou = (df["houve_internacao"] == "sim").sum()
    pendentes = (df["status"] != "concluido").sum()
    valor = pd.to_numeric(df["valor_estimado"], errors="coerce").fillna(0).sum()

    por_unidade = df["unidade"].fillna("(sem unidade)").value_counts()
    por_tipo = df["tipo_atendimento"].fillna("(sem tipo)").value_counts()
    por_status = df["status"].fillna("(sem status)").value_counts()

    linhas = [
        f"# Relatorio mensal - {mes}",
        "",
        f"- Total de atendimentos: **{total}**",
        f"- Internados (informado): **{internou}**",
        f"- Casos nao concluidos: **{pendentes}**",
        f"- Valor estimado acumulado: **R$ {valor:,.2f}**",
        "",
        "## Por unidade",
        *[f"- {u}: {n}" for u, n in por_unidade.items()],
        "",
        "## Por tipo de atendimento",
        *[f"- {t}: {n}" for t, n in por_tipo.items()],
        "",
        "## Por status",
        *[f"- {s}: {n}" for s, n in por_status.items()],
    ]
    return "\n".join(linhas)


def garantir_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def nome_arquivo(prefixo: str, ext: str) -> str:
    return f"{prefixo}-{date.today().isoformat()}.{ext}"
