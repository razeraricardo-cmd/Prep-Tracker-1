"""Cockpit Infectologia - modulo principal."""
__version__ = "0.1.0"
