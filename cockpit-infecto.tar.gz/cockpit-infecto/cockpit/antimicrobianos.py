"""Checklist e alertas de antibioticoterapia."""
from __future__ import annotations

import re
from typing import Iterable

VIAS = ["EV", "VO", "IM", "SC", "INALATORIO", "TOPICO"]

# Mapas simples de alergia cruzada / mesma classe.
GRUPOS = {
    "PENICILINA": {"penicilina", "amoxicilina", "ampicilina", "piperacilina", "oxacilina", "ticarcilina"},
    "CEFALOSPORINA": {"cefazolina", "cefalexina", "ceftriaxona", "cefepime", "ceftazidima", "ceftolozano"},
    "CARBAPENEMICO": {"meropenem", "imipenem", "ertapenem", "doripenem"},
    "MACROLIDEO": {"azitromicina", "claritromicina", "eritromicina"},
    "FLUOROQUINOLONA": {"ciprofloxacino", "levofloxacino", "moxifloxacino"},
    "GLICOPEPTIDEO": {"vancomicina", "teicoplanina"},
    "LIPOGLICOPEPTIDEO": {"dalbavancina", "oritavancina", "telavancina"},
    "AMINOGLICOSIDEO": {"amicacina", "gentamicina", "tobramicina"},
    "OXAZOLIDINONA": {"linezolida", "tedizolida"},
    "LINCOSAMIDA": {"clindamicina"},
    "POLIMIXINA": {"polimixina", "colistina"},
}


def alertas_alergia(alergias: str | None, antimicrobianos: list[dict]) -> list[str]:
    """Retorna lista de alertas se houver suspeita de cruzamento alergia x prescricao."""
    if not alergias or not antimicrobianos:
        return []
    alerg = alergias.lower()
    alertas: list[str] = []
    for atb in antimicrobianos:
        nome = (atb.get("nome") or "").strip().lower()
        if not nome:
            continue
        # match direto
        for token in re.findall(r"[a-zA-Z]+", alerg):
            if token and len(token) >= 4 and token in nome:
                alertas.append(
                    f"ALERTA: paciente refere alergia a '{token}' e ha prescricao de {atb.get('nome')}."
                )
        # grupo cruzado
        for grupo, membros in GRUPOS.items():
            if any(m in nome for m in membros):
                for membro_alerg in membros:
                    if membro_alerg in alerg and membro_alerg not in nome:
                        alertas.append(
                            f"ALERTA: alergia relatada inclui '{membro_alerg}' (grupo {grupo}); "
                            f"prescricao de {atb.get('nome')} pertence ao mesmo grupo."
                        )
                        break
    # dedup preservando ordem
    visto: set[str] = set()
    out: list[str] = []
    for a in alertas:
        if a not in visto:
            visto.add(a)
            out.append(a)
    return out


def alertas_ajuste_renal(antimicrobianos: list[dict], tfg: float | None) -> list[str]:
    """Avisa quando ATB que necessita ajuste renal nao tem dose anotada."""
    if not antimicrobianos:
        return []
    precisa_ajuste = {
        "vancomicina", "meropenem", "imipenem", "ertapenem", "piperacilina",
        "ceftazidima", "cefepime", "amicacina", "gentamicina", "tobramicina",
        "levofloxacino", "ciprofloxacino", "fluconazol", "aciclovir",
        "ganciclovir", "valaciclovir", "valganciclovir", "polimixina", "colistina",
        "daptomicina", "trimetoprim",
    }
    out: list[str] = []
    for atb in antimicrobianos:
        nome = (atb.get("nome") or "").lower()
        if any(p in nome for p in precisa_ajuste):
            if tfg is not None and tfg < 50:
                if not (atb.get("dose") and atb.get("intervalo")):
                    out.append(
                        f"AJUSTE RENAL: '{atb.get('nome')}' geralmente requer ajuste para TFG {tfg:.0f}."
                    )
    return out


def vias_validas() -> Iterable[str]:
    return VIAS
