"""Integracao LLM opcional. Off por padrao - exige chave + consentimento explicito.

Funcao unica: dado um texto bruto, devolve dicionario com campos extraidos.
Nada vai pro LLM sem `consentimento=True` e ANTHROPIC_API_KEY configurada.
"""
from __future__ import annotations

import json
import os
from typing import Any

SYSTEM = """Voce extrai campos estruturados de um relato medico de interconsulta infectologica.
Responda APENAS com um JSON valido com estas chaves (use string vazia se faltar):
  paciente, matricula, idade, unidade, solicitante, demanda,
  alergias, culturas, conduta_orientada, pendencias, hpma,
  antimicrobianos (array de objetos com chaves: nome, dose, via, intervalo, duracao, em_uso (bool)).
Nao invente dados. Use strings em portugues brasileiro. Nao adicione comentarios fora do JSON.
"""


def disponivel() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def extrair_campos(texto: str, consentimento: bool, modelo: str = "claude-sonnet-4-6") -> dict[str, Any]:
    if not consentimento:
        raise PermissionError("Necessario consentimento explicito para enviar texto ao LLM.")
    if not disponivel():
        raise RuntimeError("ANTHROPIC_API_KEY ausente.")
    if not texto.strip():
        return {}

    import anthropic  # import tardio para nao quebrar quando rodar offline

    client = anthropic.Anthropic()
    msg = client.messages.create(
        model=modelo,
        max_tokens=2048,
        system=SYSTEM,
        messages=[{"role": "user", "content": texto}],
    )
    raw = ""
    for block in msg.content:
        if getattr(block, "type", None) == "text":
            raw += block.text
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        raw = raw.split("\n", 1)[1] if "\n" in raw else raw
        raw = raw.rstrip("`").strip()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    if "antimicrobianos" not in data or not isinstance(data["antimicrobianos"], list):
        data["antimicrobianos"] = []
    return data
