"""SQLite schema e queries para o Cockpit."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path
from typing import Iterator, Any

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "cockpit.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS casos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  criado_em TEXT NOT NULL,
  atualizado_em TEXT NOT NULL,
  data_atendimento TEXT NOT NULL,
  paciente TEXT,
  matricula TEXT,
  idade TEXT,
  unidade TEXT,
  solicitante TEXT,
  tipo_atendimento TEXT,
  demanda TEXT,
  alergias TEXT,
  texto_bruto TEXT,
  antimicrobianos TEXT,  -- JSON array
  culturas TEXT,
  exames_padronizados TEXT,
  conduta_orientada TEXT,
  pendencias TEXT,
  houve_internacao TEXT,  -- 'sim' | 'nao' | 'indefinido'
  status TEXT,            -- 'concluido' | 'pendente' | 'aguardando_exames' | 'revisar'
  valor_estimado REAL,
  observacoes TEXT,
  evolucao_gerada TEXT
);

CREATE INDEX IF NOT EXISTS idx_casos_data ON casos(data_atendimento);
CREATE INDEX IF NOT EXISTS idx_casos_unidade ON casos(unidade);
CREATE INDEX IF NOT EXISTS idx_casos_status ON casos(status);
CREATE INDEX IF NOT EXISTS idx_casos_paciente ON casos(paciente);
CREATE INDEX IF NOT EXISTS idx_casos_matricula ON casos(matricula);
"""


def db_path() -> Path:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return DB_PATH


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _dumps(value: Any) -> str | None:
    if value is None or value == [] or value == {}:
        return None
    return json.dumps(value, ensure_ascii=False)


def _loads(value: str | None) -> Any:
    if not value:
        return None
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return None


def insert_caso(data: dict) -> int:
    now = _now()
    payload = {
        "criado_em": now,
        "atualizado_em": now,
        "data_atendimento": data.get("data_atendimento") or date.today().isoformat(),
        "paciente": data.get("paciente"),
        "matricula": data.get("matricula"),
        "idade": data.get("idade"),
        "unidade": data.get("unidade"),
        "solicitante": data.get("solicitante"),
        "tipo_atendimento": data.get("tipo_atendimento"),
        "demanda": data.get("demanda"),
        "alergias": data.get("alergias"),
        "texto_bruto": data.get("texto_bruto"),
        "antimicrobianos": _dumps(data.get("antimicrobianos")),
        "culturas": data.get("culturas"),
        "exames_padronizados": data.get("exames_padronizados"),
        "conduta_orientada": data.get("conduta_orientada"),
        "pendencias": data.get("pendencias"),
        "houve_internacao": data.get("houve_internacao") or "indefinido",
        "status": data.get("status") or "concluido",
        "valor_estimado": data.get("valor_estimado"),
        "observacoes": data.get("observacoes"),
        "evolucao_gerada": data.get("evolucao_gerada"),
    }
    with connect() as conn:
        cols = ", ".join(payload.keys())
        placeholders = ", ".join(["?"] * len(payload))
        cur = conn.execute(
            f"INSERT INTO casos ({cols}) VALUES ({placeholders})",
            tuple(payload.values()),
        )
        return cur.lastrowid


def list_casos(
    data_de: str | None = None,
    data_ate: str | None = None,
    unidade: str | None = None,
    status: str | None = None,
    tipo_atendimento: str | None = None,
    busca: str | None = None,
    limit: int = 500,
) -> list[dict]:
    sql = "SELECT * FROM casos WHERE 1=1"
    params: list[Any] = []
    if data_de:
        sql += " AND data_atendimento >= ?"
        params.append(data_de)
    if data_ate:
        sql += " AND data_atendimento <= ?"
        params.append(data_ate)
    if unidade:
        sql += " AND unidade = ?"
        params.append(unidade)
    if status:
        sql += " AND status = ?"
        params.append(status)
    if tipo_atendimento:
        sql += " AND tipo_atendimento = ?"
        params.append(tipo_atendimento)
    if busca:
        like = f"%{busca}%"
        sql += (
            " AND ("
            "paciente LIKE ? OR matricula LIKE ? OR demanda LIKE ?"
            " OR texto_bruto LIKE ? OR culturas LIKE ? OR antimicrobianos LIKE ?"
            ")"
        )
        params.extend([like] * 6)
    sql += " ORDER BY data_atendimento DESC, id DESC LIMIT ?"
    params.append(limit)
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [_row_to_dict(r) for r in rows]


def get_caso(caso_id: int) -> dict | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM casos WHERE id = ?", (caso_id,)).fetchone()
    return _row_to_dict(row) if row else None


def update_caso(caso_id: int, fields: dict) -> None:
    fields = {k: v for k, v in fields.items() if k not in {"id", "criado_em"}}
    if "antimicrobianos" in fields and not isinstance(fields["antimicrobianos"], (str, type(None))):
        fields["antimicrobianos"] = _dumps(fields["antimicrobianos"])
    fields["atualizado_em"] = _now()
    sets = ", ".join(f"{k} = ?" for k in fields)
    with connect() as conn:
        conn.execute(
            f"UPDATE casos SET {sets} WHERE id = ?",
            (*fields.values(), caso_id),
        )


def delete_caso(caso_id: int) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM casos WHERE id = ?", (caso_id,))


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["antimicrobianos"] = _loads(d.get("antimicrobianos")) or []
    return d


def list_unidades() -> list[str]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT DISTINCT unidade FROM casos WHERE unidade IS NOT NULL AND unidade != '' ORDER BY unidade"
        ).fetchall()
    return [r["unidade"] for r in rows]


def list_tipos() -> list[str]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT DISTINCT tipo_atendimento FROM casos "
            "WHERE tipo_atendimento IS NOT NULL AND tipo_atendimento != '' ORDER BY tipo_atendimento"
        ).fetchall()
    return [r["tipo_atendimento"] for r in rows]
