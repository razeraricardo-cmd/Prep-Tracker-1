"""Anonimizacao de nomes e matriculas para export e LLM."""
from __future__ import annotations

import os
import re


def iniciais(nome: str | None) -> str:
    if not nome:
        return ""
    partes = [p for p in re.split(r"\s+", nome.strip()) if p]
    return "".join(p[0].upper() for p in partes if p[0].isalpha())[:4]


def mascarar_matricula(mat: str | None) -> str:
    if not mat:
        return ""
    mat = mat.strip()
    if len(mat) <= 4:
        return "*" * len(mat)
    return mat[:2] + "*" * (len(mat) - 4) + mat[-2:]


def anonimizar_texto(texto: str | None, nome: str | None, matricula: str | None) -> str:
    if not texto:
        return ""
    out = texto
    if nome:
        for p in nome.strip().split():
            if len(p) >= 3:
                out = re.sub(re.escape(p), "[NOME]", out, flags=re.IGNORECASE)
    if matricula:
        out = out.replace(matricula, mascarar_matricula(matricula))
    return out


def deve_anonimizar(default: bool | None = None) -> bool:
    raw = os.environ.get("COCKPIT_ANONIMIZAR")
    if raw is None:
        return True if default is None else default
    return raw not in {"0", "false", "False", ""}
