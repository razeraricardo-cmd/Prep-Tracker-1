"""Gerador deterministico de evolucoes via Jinja2."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import ChainableUndefined, Environment, FileSystemLoader

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"


def _atb_linha(atb: dict[str, Any]) -> str:
    nome = (atb.get("nome") or "").strip().upper()
    dose = (atb.get("dose") or "").strip()
    via = (atb.get("via") or "").strip().upper()
    intervalo = (atb.get("intervalo") or "").strip()
    dur = (atb.get("duracao") or "").strip()
    partes = [p for p in [nome, dose, via, intervalo] if p]
    if not partes:
        return ""
    linha = "- " + " ".join(partes)
    if dur:
        linha += f" POR {dur}"
    return linha


def gerar_evolucao(caso: dict) -> str:
    env = Environment(
        loader=FileSystemLoader(TEMPLATE_DIR),
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
        undefined=ChainableUndefined,
    )
    env.globals["atb_linha"] = _atb_linha
    tmpl = env.get_template("evolucao.j2")
    ctx = {**caso, "antimicrobianos": caso.get("antimicrobianos") or [], "hd": caso.get("hd") or []}
    return tmpl.render(c=ctx).strip()
