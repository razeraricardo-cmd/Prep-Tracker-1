"""Padronizador de exames: texto bruto -> linha unica com abreviacoes medicas."""
from __future__ import annotations

import re
from typing import Iterable

# Mapeia regex -> sigla canonica. Ordem importa (mais especifico primeiro).
PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b(hemoglobina|hb|hgb)\b", re.IGNORECASE), "HB"),
    (re.compile(r"\b(hematocrito|hto|ht)\b", re.IGNORECASE), "HT"),
    (re.compile(r"\b(leucocitos|leuco|wbc|gb)\b", re.IGNORECASE), "LEUCO"),
    (re.compile(r"\b(neutrofilos|neutr|neu)\b", re.IGNORECASE), "NEU"),
    (re.compile(r"\b(linfocitos|linf|ly)\b", re.IGNORECASE), "LINF"),
    (re.compile(r"\b(plaquetas|plaq|plt)\b", re.IGNORECASE), "PLAQ"),
    (re.compile(r"\b(creatinina|cr|creat)\b", re.IGNORECASE), "CR"),
    (re.compile(r"\b(ureia|ur|u)\b", re.IGNORECASE), "U"),
    (re.compile(r"\b(sodio|na|sodium)\b", re.IGNORECASE), "NA"),
    (re.compile(r"\b(potassio|k|potassium)\b", re.IGNORECASE), "K"),
    (re.compile(r"\b(cloro|cl)\b", re.IGNORECASE), "CL"),
    (re.compile(r"\b(magnesio|mg)\b", re.IGNORECASE), "MG"),
    (re.compile(r"\b(calcio|ca)\b", re.IGNORECASE), "CA"),
    (re.compile(r"\b(fosforo|p)\b", re.IGNORECASE), "P"),
    (re.compile(r"\b(pcr|proteina[\s_-]?c[\s_-]?reativa|crp)\b", re.IGNORECASE), "PCR"),
    (re.compile(r"\b(procalcitonina|pct)\b", re.IGNORECASE), "PCT"),
    (re.compile(r"\b(lactato|lactate)\b", re.IGNORECASE), "LAC"),
    (re.compile(r"\b(bilirrubina[\s_-]?total|bt)\b", re.IGNORECASE), "BT"),
    (re.compile(r"\b(bilirrubina[\s_-]?direta|bd)\b", re.IGNORECASE), "BD"),
    (re.compile(r"\b(ast|tgo)\b", re.IGNORECASE), "AST"),
    (re.compile(r"\b(alt|tgp)\b", re.IGNORECASE), "ALT"),
    (re.compile(r"\b(fosfatase[\s_-]?alcalina|fa|alp)\b", re.IGNORECASE), "FA"),
    (re.compile(r"\b(ggt|gamagt)\b", re.IGNORECASE), "GGT"),
    (re.compile(r"\b(inr)\b", re.IGNORECASE), "INR"),
    (re.compile(r"\b(rni)\b", re.IGNORECASE), "RNI"),
    (re.compile(r"\b(tap)\b", re.IGNORECASE), "TAP"),
    (re.compile(r"\b(ttpa|aptt)\b", re.IGNORECASE), "TTPA"),
    (re.compile(r"\b(d[\s\-]?dimer|d[\s\-]?dimero)\b", re.IGNORECASE), "DDIM"),
    (re.compile(r"\b(troponina[\s_-]?i?|tnp)\b", re.IGNORECASE), "TNP"),
    (re.compile(r"\b(bnp)\b", re.IGNORECASE), "BNP"),
    (re.compile(r"\b(nt[\s\-]?probnp)\b", re.IGNORECASE), "NT-PROBNP"),
    (re.compile(r"\b(glicemia|glicose|glu)\b", re.IGNORECASE), "GLI"),
    (re.compile(r"\b(albumina|alb)\b", re.IGNORECASE), "ALB"),
    (re.compile(r"\b(vhs|esr)\b", re.IGNORECASE), "VHS"),
    (re.compile(r"\b(tgo)\b", re.IGNORECASE), "AST"),
]

# Captura valor numerico apos a sigla, com opcional unidade %, mg/dL, etc.
VALUE_RE = re.compile(
    r"(?P<num>-?\d+(?:[.,]\d+)?)\s*(?:%|mg/dl|mg/dL|mmol/L|mEq/L|U/L|ng/mL|U/mL|UI/L|UI/mL|s|seg|/uL|/mm3)?",
    re.IGNORECASE,
)


def padronizar_exames(texto: str) -> str:
    """Recebe um texto bruto com exames e devolve uma linha unica padronizada.

    Estrategia:
    1. Para cada pattern conhecido, encontra a sigla no texto.
    2. Procura o proximo valor numerico apos a sigla.
    3. Constroi a linha "SIGLA VALOR | SIGLA VALOR | ...".
    4. Ignora referencias entre parenteses ou colchetes.
    """
    if not texto:
        return ""

    limpo = re.sub(r"\([^)]*\)", " ", texto)
    limpo = re.sub(r"\[[^\]]*\]", " ", limpo)
    limpo = re.sub(r"valores? de referencia[^\n]*", " ", limpo, flags=re.IGNORECASE)

    encontrados: list[tuple[int, str, str]] = []
    vistos: set[str] = set()

    for pat, sigla in PATTERNS:
        if sigla in vistos:
            continue
        m = pat.search(limpo)
        if not m:
            continue
        tail = limpo[m.end():m.end() + 80]
        val = VALUE_RE.search(tail)
        if not val:
            continue
        valor = val.group("num").replace(",", ".")
        try:
            n = float(valor)
        except ValueError:
            continue
        valor_fmt = _fmt(n, sigla)
        encontrados.append((m.start(), sigla, valor_fmt))
        vistos.add(sigla)

    encontrados.sort(key=lambda x: x[0])
    return " | ".join(f"{s} {v}" for _, s, v in encontrados)


def _fmt(n: float, sigla: str) -> str:
    inteiros = {"LEUCO", "NEU", "LINF", "PLAQ"}
    if sigla in inteiros:
        return f"{int(round(n))}"
    if abs(n - int(n)) < 1e-9:
        return f"{int(n)}"
    return f"{n:.1f}".rstrip("0").rstrip(".") or f"{n:.2f}"


def conhecidos() -> Iterable[str]:
    return sorted({s for _, s in PATTERNS})
