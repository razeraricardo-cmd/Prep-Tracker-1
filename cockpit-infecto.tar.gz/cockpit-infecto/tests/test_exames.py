from cockpit.exames import padronizar_exames


def test_padroniza_simples():
    txt = "Hb 10,9 Ht 32,1% Leucocitos 12300 Plaq 250000 Cr 1,2 Na 138 K 4,2"
    out = padronizar_exames(txt)
    assert "HB 10.9" in out
    assert "HT 32.1" in out
    assert "LEUCO 12300" in out
    assert "PLAQ 250000" in out
    assert "CR 1.2" in out
    assert "NA 138" in out
    assert "K 4.2" in out


def test_ignora_valores_de_referencia():
    txt = "Hb 10,9 (12 a 16) Plaq 250000 (150000 a 400000)"
    out = padronizar_exames(txt)
    assert "HB 10.9" in out
    assert "PLAQ 250000" in out


def test_texto_vazio():
    assert padronizar_exames("") == ""
    assert padronizar_exames(None) == ""
