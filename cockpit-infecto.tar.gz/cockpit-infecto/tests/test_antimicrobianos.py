from cockpit.antimicrobianos import alertas_alergia, alertas_ajuste_renal


def test_alerta_alergia_direta():
    alertas = alertas_alergia("alergia a penicilina", [{"nome": "amoxicilina"}])
    assert alertas, "deveria alertar cruzamento penicilina x amoxicilina"
    assert any("PENICILINA" in a or "penicilina" in a.lower() for a in alertas)


def test_sem_alergia_nao_alerta():
    assert alertas_alergia("", [{"nome": "ceftriaxona"}]) == []
    assert alertas_alergia(None, [{"nome": "ceftriaxona"}]) == []


def test_ajuste_renal_avisa_quando_tfg_baixa():
    alertas = alertas_ajuste_renal([{"nome": "vancomicina"}], tfg=30)
    assert alertas
