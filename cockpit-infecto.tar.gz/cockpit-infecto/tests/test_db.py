import importlib
from pathlib import Path


def test_db_init_e_insert(tmp_path, monkeypatch):
    # redireciona o DB para o tmp
    monkeypatch.setenv("HOME", str(tmp_path))
    import cockpit.db as db
    importlib.reload(db)
    monkeypatch.setattr(db, "DB_PATH", tmp_path / "test.db")

    db.init_db()
    cid = db.insert_caso({
        "data_atendimento": "2026-05-01",
        "paciente": "Teste",
        "matricula": "999",
        "unidade": "X",
        "demanda": "y",
        "status": "concluido",
    })
    assert cid > 0
    casos = db.list_casos(data_de="2026-04-01", data_ate="2026-06-01")
    assert any(c["id"] == cid for c in casos)

    db.update_caso(cid, {"status": "pendente"})
    c = db.get_caso(cid)
    assert c["status"] == "pendente"

    db.delete_caso(cid)
    assert db.get_caso(cid) is None
