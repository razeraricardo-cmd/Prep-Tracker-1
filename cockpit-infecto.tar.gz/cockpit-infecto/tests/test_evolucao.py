from cockpit.evolucao import gerar_evolucao


def test_evolucao_minima_tem_secoes_obrigatorias():
    caso = {
        "paciente": "Paciente Teste",
        "matricula": "12345",
        "unidade": "UI",
        "solicitante": "Dr X",
        "demanda": "avaliacao",
        "texto_bruto": "Paciente com pneumonia, em uso de ceftriaxona.",
        "antimicrobianos": [],
        "conduta_orientada": "manter ceftriaxona\nsolicitar cultura",
    }
    ev = gerar_evolucao(caso)
    assert "PACIENTE: Paciente Teste" in ev
    assert "DEMANDA: avaliacao" in ev
    assert "HPMA:" in ev
    assert "HD:" in ev
    assert "CONDUTA:" in ev
    assert "EQUIPE À DISPOSIÇÃO, RECONVOCAR SE NECESSÁRIO" in ev
    assert "INTERCONSULTA CLÍNICA DISCUTIDA VIA TELEMEDICINA" in ev


def test_evolucao_separa_atb_em_uso_e_previo():
    caso = {
        "paciente": "X",
        "demanda": "X",
        "texto_bruto": "hpma",
        "antimicrobianos": [
            {"nome": "ceftriaxona", "dose": "2g", "via": "EV", "intervalo": "1x/dia", "duracao": "7 dias", "em_uso": True},
            {"nome": "amoxicilina", "dose": "500mg", "via": "VO", "intervalo": "8/8h", "duracao": "5 dias", "em_uso": False},
        ],
    }
    ev = gerar_evolucao(caso)
    assert "EM USO" in ev
    assert "PRÉVIOS" in ev
    assert "CEFTRIAXONA" in ev
    assert "AMOXICILINA" in ev


def test_evolucao_anexa_observacoes_se_houver_pendencias():
    caso = {
        "paciente": "X", "demanda": "X", "texto_bruto": "h",
        "pendencias": "checar creatinina\naguardar cultura",
    }
    ev = gerar_evolucao(caso)
    assert "OBSERVAÇÕES PARA MIM" in ev
    assert "checar creatinina" in ev
