# Cockpit Infectologia

Aplicacao local em Streamlit + SQLite para registrar casos de interconsulta infectologica, padronizar exames, gerar evolucoes prontas para o prontuario e exportar produtividade.

**Este sistema nao substitui julgamento medico.** Sempre revise antes de copiar.

## Recursos

- Cadastro de casos com campos estruturados (paciente, matricula, unidade, demanda, alergias, antimicrobianos, culturas, exames)
- Padronizador de exames bruto -> linha unica com abreviacoes medicas
- Checklist de antimicrobianos com alertas de alergia cruzada e ajuste renal
- Geracao deterministica de evolucao no modelo Hospital Virtual Infectologia (Jinja2)
- Historico pesquisavel por paciente, matricula, unidade, status, tipo, periodo, antibiotico, cultura, foco
- Dashboard com totais diarios/semanais/mensais, quebra por unidade/tipo/status, valor estimado
- Export CSV, XLSX, TXT do dia, relatorio mensal Markdown
- Anonimizacao opcional de nomes e matriculas
- Integracao opcional com Claude (off por padrao) para extrair campos de texto bruto

## Privacidade

- Tudo roda local. Banco SQLite em `data/cockpit.db`.
- Nada e enviado para internet, exceto se voce ativar manualmente a aba "Estruturar texto bruto com IA" + marcar a caixa de consentimento.
- Anonimizacao ligada por padrao (`COCKPIT_ANONIMIZAR=1`).
- Exclusao definitiva de registros disponivel no Historico.

## Instalacao

```sh
git clone https://github.com/SEU-USUARIO/cockpit-infecto
cd cockpit-infecto
chmod +x run.sh
./run.sh
```

O `run.sh` cria um virtualenv, instala dependencias e abre `streamlit run app.py` em http://localhost:8501.

Manualmente:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Configuracao

Copie `.env.example` para `.env` e edite:

```
COCKPIT_ANONIMIZAR=1
ANTHROPIC_API_KEY=     # opcional, habilita extracao IA
```

Para carregar dados ficticios de exemplo:

```sh
python -m seeds.load_seeds
```

## Testes

```sh
pytest -q
```

## Estrutura

```
cockpit-infecto/
  app.py                       # entry Streamlit
  cockpit/
    db.py                      # SQLite + queries
    evolucao.py                # gerador deterministico (Jinja2)
    exames.py                  # padronizador regex
    antimicrobianos.py         # checklist + alertas
    anonimizar.py              # mascaras de nome/matricula
    export.py                  # CSV/XLSX/TXT/Markdown
    llm.py                     # extracao opcional via Claude
  pages/                       # paginas Streamlit
  templates/evolucao.j2        # template Jinja2 da evolucao
  tests/                       # pytest
  seeds/                       # dados ficticios + loader
  data/                        # banco SQLite (gerado)
  exports/                     # destinos de export (gerado)
```

## Aviso clinico

- Nao inventa dados ausentes.
- Quando algo nao estiver claro, vai para "OBSERVACOES PARA MIM - NAO COPIAR NO PRONTUARIO".
- Diferencia ATB em uso de ATB orientado.
- Nao indica alta/internacao diretamente - decisao da equipe assistente presencial.
- Inclui disclaimer fixo de telemedicina em toda evolucao.

## Gaps conhecidos (deste MVP)

- Sem dose-recommendation automatica por TFG; alertas apontam necessidade, mas a dose final e responsabilidade do medico.
- LLM extrai campos; nao revisa criticamente o caso.
- Sem importacao de PDF/print (use Cockpit + cole o texto OU use o app Hospital Virtual Next.js separado).
