"""Cockpit Infectologia - entrypoint Streamlit.

Rodar: streamlit run app.py
"""
from __future__ import annotations

import streamlit as st

from cockpit.db import init_db

st.set_page_config(
    page_title="Cockpit Infectologia",
    page_icon=":mag:",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()

st.title("Cockpit Infectologia")
st.markdown(
    """
Aplicacao local para registrar casos infectologicos, gerar evolucoes padronizadas,
controlar pendencias e exportar produtividade.

**Use a barra lateral para navegar:**
- **Novo caso** - cadastra um caso, padroniza exames e gera a evolucao
- **Historico** - busca, filtra e edita casos salvos
- **Dashboard** - totais e quebras por unidade / tipo / status
- **Exportar** - CSV, XLSX, TXT do dia e relatorio mensal
"""
)

st.info(
    "Este sistema **nao substitui o julgamento medico**. Confira sempre a evolucao gerada "
    "antes de copiar para o prontuario.",
    icon=":warning:",
)

st.caption(
    "Tudo roda local. Banco SQLite em `data/cockpit.db`. "
    "Integracao com LLM (opcional) requer chave e consentimento por caso."
)
