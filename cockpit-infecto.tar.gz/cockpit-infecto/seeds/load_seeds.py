"""Carrega casos ficticios no banco local. Idempotente nao e: roda manualmente."""
import json
from pathlib import Path

from cockpit import db, evolucao

SEED = Path(__file__).resolve().parent / "casos_ficticios.json"


def main() -> None:
    db.init_db()
    data = json.loads(SEED.read_text(encoding="utf-8"))
    for caso in data:
        caso["evolucao_gerada"] = evolucao.gerar_evolucao({**caso, "hpma": caso.get("texto_bruto"), "hd": []})
        cid = db.insert_caso(caso)
        print(f"inserido caso #{cid}: {caso.get('paciente')}")


if __name__ == "__main__":
    main()
