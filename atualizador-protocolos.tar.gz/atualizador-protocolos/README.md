# Atualizador de Protocolos - Infectologia

Base local de conhecimento medico. Indexa PDFs, DOCX, MD e TXT da pasta
`knowledge_base/`, extrai recomendacoes estruturadas, compara protocolos locais
com evidencia externa, responde perguntas citando as fontes e gera relatorios
de revisao.

**Nao substitui julgamento clinico.** Sempre confronte com o documento original
antes de alterar conduta.

## Recursos

- Ingestao multi-formato (PDF via PyMuPDF, DOCX via python-docx, MD/TXT)
- Hash do arquivo para detectar alteracoes e re-indexar
- Deteccao heuristica de tipo (guideline, protocolo_local, artigo, anotacao), area, data e versao
- Chunking em paragrafos com indice (chunks <= ~1800 chars)
- Busca local BM25 + fuzzy via rapidfuzz, sem embeddings pesados
- Extracao de recomendacoes: heuristica por gatilhos linguisticos + opcional via Claude
- Comparador local x externo: similaridade + diffs de duracao/droga/estrategia
- Q&A na base com citacoes (sem LLM por padrao; com LLM se opt-in)
- Relatorios: revisao mensal (antigos + a revisar), por tema, exportaveis em MD/DOCX
- Dashboard com totais, idade dos documentos, status de revisao
- Export XLSX de documentos e recomendacoes

## Privacidade

- Roda 100% local. Banco SQLite em `data/atualizador.db`.
- Nenhum documento sai do seu disco a menos que voce ative a IA + marque consentimento.
- Threshold "protocolo antigo" configuravel via `PROTOCOL_AGE_THRESHOLD_MONTHS`.

## Instalacao

```sh
git clone https://github.com/SEU-USUARIO/atualizador-protocolos
cd atualizador-protocolos
cp .env.example .env       # opcional
chmod +x run.sh
./run.sh
```

Acessa em http://localhost:8501.

Manualmente:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Uso

1. Coloque seus arquivos em `knowledge_base/` (subpastas funcionam).
2. Abra a aba **Documentos** e clique em "Re-indexar pasta".
3. Em **Recomendacoes**, escolha um documento e use "Extrair com heuristica" ou (opt-in) "Extrair com IA".
4. Em **Comparar protocolos**, cole o texto da nova diretriz e compare com seu protocolo local.
5. Em **Perguntar a base**, faca perguntas; o sistema mostra trechos + fontes. Marque consentimento se quiser que a IA sintetize.
6. Em **Relatorios**, gere a revisao mensal e relatorios por tema.

## Estrutura

```
atualizador-protocolos/
  app.py
  atualizador/
    db.py            # SQLite (documents, chunks, recommendations, comparisons, reports)
    ingest.py        # multi-formato + hash + deteccao
    search.py        # BM25 simples + fuzzy
    recommendations.py
    comparator.py
    qa.py            # perguntas com citacao
    reports.py       # revisao mensal, por tema
    export.py        # XLSX
  pages/
  templates/
  tests/             # pytest
  knowledge_base/    # SEUS arquivos (gitignorado)
  data/              # banco
  exports/           # relatorios gerados
```

## Testes

```sh
pytest -q
```

## Aviso clinico

- O comparador heuristico nao substitui leitura comparativa formal entre diretriz e protocolo.
- A extracao heuristica de recomendacoes pega frases candidatas; a verificacao final e sua.
- A IA, quando ativada, recebe trechos truncados (ate ~18 mil chars); para documentos longos, considere ingerir capitulos em arquivos separados.
- Preprints e estudos pequenos devem ser tratados como hipotese, nao recomendacao.

## Gaps conhecidos (MVP)

- Sem embeddings semanticos (FAISS/Chroma). A busca usa BM25 + fuzzy; cobre bem o uso pessoal.
- Sem agendamento integrado ao Radar de Evidencias (use o Radar separado e referencie aqui).
- Comparacao com fonte externa exige cole-e-cola; ainda nao puxa direto do PubMed.
