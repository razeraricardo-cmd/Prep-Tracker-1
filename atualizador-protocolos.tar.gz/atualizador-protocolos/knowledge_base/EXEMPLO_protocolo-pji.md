# Protocolo local - Infeccao de protese articular (PJI)

Versao: 1.0
Data: 2023-08-01

## Definicao
PJI agudo: ate 4 semanas pos-cirurgia ou ate 3 semanas de sintomas em PJI hematogenico.

## Conduta inicial
Em PJI agudo, considerar DAIR como estrategia cirurgica.
Iniciar antibioticoterapia empirica EV ampla apos cultura cirurgica.

## Antibioticoterapia
Quando S aureus oxacilina-sensivel: cefazolina 2g EV 8/8h.
Quando S aureus oxacilina-resistente: vancomicina conforme AUC alvo.
Apos resolucao de bacteremia, adicionar rifampicina 600mg VO 12/12h ao esquema.
Duracao total habitual: 12 semanas para PJI manejado com DAIR.

## Criterios de troca EV para VO
Apos 2 semanas EV, com boa evolucao clinica, considerar oral switch com agente ativo na biopelicula.

## Observacoes
- Source control e fundamental.
- Considerar terapia supressiva em casos selecionados.
