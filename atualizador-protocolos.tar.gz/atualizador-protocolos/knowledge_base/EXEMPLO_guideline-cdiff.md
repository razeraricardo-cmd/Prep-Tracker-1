# Guideline - Clostridioides difficile infection (resumo)

Versao: 2024.1
Source: IDSA/SHEA 2024

## Recomendacoes

Recommendation 1: First episode of CDI in adults - we recommend fidaxomicin over vancomycin (strong recommendation, high quality evidence).

Recommendation 2: For recurrent CDI we recommend a strategy that includes fidaxomicin or bezlotoxumab (moderate certainty).

Recommendation 3: Fecal microbiota transplantation (FMT) is recommended for multiply recurrent CDI failing other therapies.

Recommendation 4: Metronidazole should be avoided as first-line for non-severe CDI.

Duration of treatment is 10 days for fidaxomicin and 10 days for oral vancomycin.

Source control with discontinuation of unnecessary antibiotics is strongly recommended.
