from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import streamlit as st

from atualizador import db, ingest

st.set_page_config(page_title="Documentos", page_icon=":file_folder:", layout="wide")
st.title("Documentos")

KB = Path(os.environ.get("KB_PATH", "./knowledge_base")).resolve()

c1, c2 = st.columns([2, 1])
c1.code(f"Pasta de documentos: {KB}")
if c2.button("Re-indexar pasta", type="primary"):
    if not KB.exists():
        st.error(f"Pasta nao existe: {KB}")
    else:
        with st.spinner("Indexando..."):
            res = ingest.ingest_dir(KB)
        st.success(f"Inseridos/atualizados: {res['inseridos']}")
        if res["erros"]:
            st.warning(f"{len(res['erros'])} erro(s):")
            for e in res["erros"]:
                st.write(f"- {e}")

uploaded = st.file_uploader("Ou faca upload manual (PDF/DOCX/MD/TXT) para a pasta", type=["pdf", "docx", "md", "txt"])
if uploaded:
    KB.mkdir(parents=True, exist_ok=True)
    dest = KB / uploaded.name
    dest.write_bytes(uploaded.read())
    try:
        ingest.ingest_file(dest)
        st.success(f"Arquivo ingerido: {dest.name}")
    except Exception as e:
        st.error(f"Falha na ingestao: {e}")

st.subheader("Documentos indexados")
area = st.selectbox("Filtrar por area", [""] + ingest.AREAS)
tipo = st.selectbox("Filtrar por tipo", ["", "guideline", "protocolo_local", "artigo", "anotacao", "outro"])
docs = db.list_documents(area=area or None, tipo=tipo or None)

if not docs:
    st.info("Nada indexado ainda.")
else:
    df = pd.DataFrame(docs)
    cols = ["id", "titulo", "tipo", "area", "data_doc", "paginas", "ingestao"]
    st.dataframe(df[cols], use_container_width=True, hide_index=True)

    sel = st.selectbox("Detalhar documento", [None] + [d["id"] for d in docs], format_func=lambda x: "" if x is None else f"#{x}")
    if sel:
        d = db.get_document(int(sel))
        if d:
            st.markdown(f"### {d['titulo']}")
            cA, cB, cC, cD = st.columns(4)
            cA.write(f"**Tipo:** {d['tipo']}")
            cB.write(f"**Area:** {d.get('area')}")
            cC.write(f"**Data:** {d.get('data_doc')}")
            cD.write(f"**Paginas/linhas:** {d.get('paginas')}")
            st.text_area("Resumo (primeiros 1000 chars)", value=d.get("resumo") or "", height=200, disabled=True)
            with st.expander("Texto completo extraido"):
                st.text(d.get("texto_completo") or "")
            if st.button(":wastebasket: Apagar documento e chunks"):
                if st.session_state.get(f"del_doc_{sel}"):
                    db.delete_document(int(sel))
                    st.success("Apagado.")
                    st.rerun()
                else:
                    st.session_state[f"del_doc_{sel}"] = True
                    st.warning("Clique novamente para confirmar.")
