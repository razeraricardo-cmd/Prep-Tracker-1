from __future__ import annotations

import os
from datetime import date, datetime

import pandas as pd
import streamlit as st

from atualizador import db

st.set_page_config(page_title="Dashboard", page_icon=":bar_chart:", layout="wide")
st.title("Dashboard")

docs = db.list_documents()
if not docs:
    st.info("Indexe documentos primeiro.")
    st.stop()

df = pd.DataFrame(docs)

threshold = int(os.environ.get("PROTOCOL_AGE_THRESHOLD_MONTHS", "18"))

def idade(s):
    if not s:
        return None
    try:
        d = datetime.fromisoformat(s[:10]).date()
    except ValueError:
        return None
    return (date.today() - d).days // 30

df["idade_meses"] = df["data_doc"].apply(idade)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Documentos", len(df))
c2.metric("Areas distintas", df["area"].nunique())
c3.metric(f"Antigos (>={threshold}m)", int(df["idade_meses"].ge(threshold).sum()))
c4.metric("Comparacoes salvas", len(db.list_comparisons()))

st.subheader("Documentos por area")
st.bar_chart(df["area"].fillna("(sem area)").value_counts())

st.subheader("Documentos por tipo")
st.bar_chart(df["tipo"].fillna("(sem tipo)").value_counts())

st.subheader("Protocolos sem revisao ha mais de N meses")
antigos = df[df["idade_meses"].notna() & df["idade_meses"].ge(threshold)]
if antigos.empty:
    st.success("Nenhum documento marcado como antigo.")
else:
    st.dataframe(
        antigos[["id", "titulo", "area", "tipo", "data_doc", "idade_meses"]].sort_values("idade_meses", ascending=False),
        use_container_width=True,
        hide_index=True,
    )
