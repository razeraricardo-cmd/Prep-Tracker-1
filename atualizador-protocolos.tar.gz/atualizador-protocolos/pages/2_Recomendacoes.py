from __future__ import annotations

import pandas as pd
import streamlit as st

from atualizador import db, recommendations

st.set_page_config(page_title="Recomendacoes", page_icon=":memo:", layout="wide")
st.title("Recomendacoes extraidas")

docs = db.list_documents()
if not docs:
    st.info("Indexe documentos primeiro em **Documentos**.")
    st.stop()

doc_sel = st.selectbox(
    "Documento",
    options=[None] + [d["id"] for d in docs],
    format_func=lambda x: "(todos)" if x is None else f"#{x} - {next(d['titulo'] for d in docs if d['id']==x)[:80]}",
)

c1, c2 = st.columns(2)
if c1.button("Extrair com heuristica do documento selecionado", disabled=doc_sel is None):
    d = db.get_document(int(doc_sel))
    if d:
        recs = recommendations.extrair_heuristica(d["id"], d.get("texto_completo") or "", d.get("area"))
        n = recommendations.persistir(recs)
        st.success(f"{n} recomendacao(oes) extraida(s).")

with c2:
    if recommendations.llm_disponivel():
        consente = st.checkbox("Consinto enviar trechos do documento para o LLM (Anthropic).")
        if st.button("Extrair com IA (Claude)", disabled=doc_sel is None or not consente):
            d = db.get_document(int(doc_sel))
            if d:
                with st.spinner("Chamando Claude..."):
                    try:
                        recs = recommendations.extrair_llm(d["id"], d.get("texto_completo") or "", d.get("area"), consente)
                        n = recommendations.persistir(recs)
                        st.success(f"{n} recomendacao(oes) via IA.")
                    except Exception as e:
                        st.error(f"Falha: {e}")
    else:
        st.caption("LLM indisponivel (sem ANTHROPIC_API_KEY).")

st.subheader("Recomendacoes na base")
recs = db.list_recommendations(documento_id=int(doc_sel) if doc_sel else None)
if not recs:
    st.info("Nenhuma recomendacao salva. Extraia acima.")
else:
    df = pd.DataFrame(recs)
    cols = ["id", "documento_titulo", "area", "recomendacao", "forca", "qualidade", "populacao", "conduta", "ano"]
    cols = [c for c in cols if c in df.columns]
    st.dataframe(df[cols], use_container_width=True, hide_index=True)
