from __future__ import annotations

import streamlit as st

from atualizador import qa

st.set_page_config(page_title="Perguntar a base", page_icon=":speech_balloon:", layout="wide")
st.title("Perguntar a base local")

st.caption("Busca trechos relevantes nos documentos indexados. So usa IA com consentimento explicito.")

q = st.text_input("Pergunta", placeholder="ex: o que meus documentos dizem sobre duracao em bacteremia por gram negativo?")
c1, c2 = st.columns(2)
top_k = c1.slider("Top-k trechos", 3, 15, 6)
usar_ia = c2.checkbox("Sintetizar com IA (Claude)") if qa.disponivel_llm() else False
consent = False
if usar_ia:
    consent = st.checkbox("Consinto enviar trechos da base para a API externa")

if st.button("Buscar", type="primary", disabled=not q.strip()):
    try:
        res = qa.responder(q, usar_llm=usar_ia, consentimento=consent, top_k=top_k)
    except Exception as e:
        st.error(str(e))
        st.stop()
    st.subheader("Resposta")
    st.markdown(res["resposta"])

    st.subheader("Fontes citadas")
    for f in res["fontes"]:
        st.markdown(f"- **{f['titulo']}** ({f['tipo']}, {f.get('data_doc')}) - `{f['caminho']}`")

    with st.expander("Trechos brutos (top-k)"):
        for i, t in enumerate(res["trechos"], 1):
            st.markdown(f"**[{i}] score {t['score']:.2f}** - documento {t.get('titulo','?')}")
            st.text(t["texto"][:1200])
            st.markdown("---")
