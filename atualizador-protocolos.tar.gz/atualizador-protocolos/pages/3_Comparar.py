from __future__ import annotations

import pandas as pd
import streamlit as st

from atualizador import comparator, db

st.set_page_config(page_title="Comparar protocolos", page_icon=":scales:", layout="wide")
st.title("Comparar protocolo local vs evidencia externa")

docs = db.list_documents()
locais = [d for d in docs if d["tipo"] == "protocolo_local"] or docs

tema = st.text_input("Tema (ex: 'duracao tratamento bacteremia gram negativo')")

c1, c2 = st.columns(2)
with c1:
    st.markdown("**Protocolo local**")
    fonte_local = st.radio("Origem", ["Documento da base", "Texto manual"], horizontal=True)
    if fonte_local == "Documento da base":
        doc_id = st.selectbox(
            "Documento",
            options=[None] + [d["id"] for d in locais],
            format_func=lambda x: "" if x is None else next(f"#{d['id']} - {d['titulo'][:80]}" for d in locais if d["id"] == x),
            key="doc_local",
        )
        texto_local = ""
        if doc_id:
            d = db.get_document(int(doc_id))
            texto_local = d.get("texto_completo") if d else ""
            st.text_area("Texto", value=(texto_local or "")[:2000], height=180, disabled=True)
    else:
        doc_id = None
        texto_local = st.text_area("Texto do protocolo local", height=220)

with c2:
    st.markdown("**Fonte externa / nova**")
    fonte_desc = st.text_input("Descricao da fonte (ex: 'IDSA PJI 2024')")
    texto_externo = st.text_area("Texto da diretriz/artigo/recomendacao", height=300)

if st.button("Comparar", type="primary", disabled=not (tema and texto_local and texto_externo)):
    comp = comparator.comparar_textos(tema, texto_local, texto_externo)
    cid = comparator.persistir(comp, doc_local_id=int(doc_id) if doc_id else None, fonte_desc=fonte_desc)
    st.success(f"Comparacao #{cid} salva.")
    st.write(f"**Status:** `{comp['status']}` - **Risco:** `{comp['risco']}`")
    st.write(f"**Mudou:** {comp['mudou']}")
    st.write(f"**Impacto:** {comp['impacto']}")
    st.write(f"**Sugestao:** {comp['sugestao']}")

st.subheader("Comparacoes salvas")
comps = db.list_comparisons()
if not comps:
    st.caption("Nenhuma.")
else:
    df = pd.DataFrame(comps)
    cols = ["id", "tema", "status", "risco", "mudou", "fonte_nova_desc", "criado_em"]
    st.dataframe(df[cols], use_container_width=True, hide_index=True)
