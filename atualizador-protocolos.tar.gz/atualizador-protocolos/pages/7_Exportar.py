from __future__ import annotations

from datetime import date

import streamlit as st

from atualizador import export

st.set_page_config(page_title="Exportar", page_icon=":outbox_tray:", layout="wide")
st.title("Exportar")

c1, c2 = st.columns(2)
c1.download_button(
    "XLSX - recomendacoes",
    data=export.recomendacoes_xlsx(),
    file_name=f"recomendacoes-{date.today().isoformat()}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)
c2.download_button(
    "XLSX - documentos",
    data=export.documentos_xlsx(),
    file_name=f"documentos-{date.today().isoformat()}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)
