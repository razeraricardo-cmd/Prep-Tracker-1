from __future__ import annotations

import streamlit as st

from atualizador import reports

st.set_page_config(page_title="Relatorios", page_icon=":chart_with_upwards_trend:", layout="wide")
st.title("Relatorios")

tab_rev, tab_tema = st.tabs(["Revisao mensal", "Por tema"])

with tab_rev:
    md = reports.relatorio_revisao_mensal()
    st.markdown(md)
    c1, c2 = st.columns(2)
    if c1.button("Salvar Markdown", key="rev_md"):
        p = reports.salvar_md(md, "revisao")
        st.success(f"Salvo em {p}")
    if c2.button("Salvar DOCX", key="rev_doc"):
        p = reports.salvar_docx(md, "revisao")
        st.success(f"Salvo em {p}")

with tab_tema:
    tema = st.text_input("Tema (ex: 'infeccao de protese articular')")
    if tema:
        md = reports.relatorio_por_tema(tema)
        st.markdown(md)
        c1, c2 = st.columns(2)
        if c1.button("Salvar Markdown", key="tema_md"):
            p = reports.salvar_md(md, f"tema-{tema[:20]}")
            st.success(f"Salvo em {p}")
        if c2.button("Salvar DOCX", key="tema_doc"):
            p = reports.salvar_docx(md, f"tema-{tema[:20]}")
            st.success(f"Salvo em {p}")
