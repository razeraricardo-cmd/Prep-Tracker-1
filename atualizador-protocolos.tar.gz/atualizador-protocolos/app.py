"""Atualizador de Protocolos - entry Streamlit."""
from __future__ import annotations

import streamlit as st

from atualizador.db import init_db

st.set_page_config(
    page_title="Atualizador de Protocolos - Infectologia",
    page_icon=":books:",
    layout="wide",
    initial_sidebar_state="expanded",
)
init_db()

st.title("Atualizador de Protocolos - Infectologia")
st.markdown(
    """
Base local de conhecimento medico:

- **Documentos** indexa PDFs, DOCX, MD, TXT da pasta `knowledge_base/`
- **Recomendacoes** extrai recomendacoes estruturadas (heuristica ou via IA)
- **Comparar protocolos** confronta protocolo local com evidencia/diretriz externa
- **Perguntar a base** responde citando documentos locais (sem inventar)
- **Relatorios** lista protocolos antigos, divergencias e temas sem cobertura
- **Dashboard** com totais e prioridades
"""
)
st.info(
    "Este sistema **nao substitui julgamento medico**. Sempre confira a fonte antes de mudar conduta.",
    icon=":warning:",
)
st.caption("Tudo local. Banco em data/atualizador.db. LLM (opcional) so dispara com consentimento explicito.")
