"""Perguntar a base: junta busca local + opcionalmente passa para LLM com citacoes."""
from __future__ import annotations

import os

from atualizador import db, search


def disponivel_llm() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def responder(pergunta: str, usar_llm: bool, consentimento: bool, top_k: int = 6) -> dict:
    """Retorna {'resposta': str, 'trechos': [...], 'fontes': [...]}.

    Se usar_llm = False, monta uma resposta determinista que lista os trechos mais relevantes
    e suas fontes. Sem inventar nada.
    """
    trechos = search.search_chunks(pergunta, top_k=top_k)
    if not trechos:
        return {
            "resposta": "Nenhum documento na base trata diretamente desta pergunta.",
            "trechos": [],
            "fontes": [],
        }

    fontes: list[dict] = []
    for t in trechos:
        doc = db.get_document(t["documento_id"])
        if doc:
            fontes.append({
                "id": doc["id"], "titulo": doc["titulo"], "tipo": doc["tipo"],
                "fonte": doc.get("fonte"), "data_doc": doc.get("data_doc"),
                "caminho": doc["caminho"],
            })

    if not usar_llm:
        partes = [f"Resposta baseada nos seguintes trechos da base local (sem IA)\n"]
        for i, t in enumerate(trechos, 1):
            doc_titulo = next((f["titulo"] for f in fontes if f["id"] == t["documento_id"]), "?")
            partes.append(
                f"{i}. **{doc_titulo}**\n"
                f"   {search.search_excerpt(t['texto'], pergunta, 280)}\n"
            )
        return {"resposta": "\n".join(partes), "trechos": trechos, "fontes": fontes}

    if not consentimento:
        raise PermissionError("Necessario consentimento para enviar trechos ao LLM.")
    if not disponivel_llm():
        raise RuntimeError("ANTHROPIC_API_KEY ausente.")

    import anthropic
    client = anthropic.Anthropic()
    contexto = "\n\n---\n\n".join(
        f"[FONTE {i+1}: {f['titulo']}]\n{t['texto'][:1800]}"
        for i, (t, f) in enumerate(zip(trechos, fontes))
    )
    sys = (
        "Voce e um infectologista respondendo perguntas APENAS com base nos trechos fornecidos. "
        "Cite cada afirmacao com [FONTE N]. Se a base nao cobrir o tema, diga isso explicitamente. "
        "Separe evidencia forte de opiniao/experiencia. Nao invente, nao extrapole. Portugues brasileiro."
    )
    user = f"PERGUNTA: {pergunta}\n\nBASE LOCAL:\n{contexto}"
    msg = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        system=sys,
        messages=[{"role": "user", "content": user}],
    )
    resposta = ""
    for b in msg.content:
        if getattr(b, "type", None) == "text":
            resposta += b.text
    return {"resposta": resposta.strip(), "trechos": trechos, "fontes": fontes}
