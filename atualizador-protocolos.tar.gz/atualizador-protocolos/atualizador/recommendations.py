"""Extracao de recomendacoes heuristica + opcional via LLM."""
from __future__ import annotations

import os
import re

from atualizador import db

# Heuristica: frases que indicam recomendacao em texto medico.
GATILHOS = [
    r"\bwe recommend\b", r"\bis recommended\b", r"\bshould be\b", r"\bguideline recommends?\b",
    r"\brecommendation\b", r"\brecomenda(?:mos|-se|do)\b", r"\bsugere(?:-se)?\b",
    r"\bdeve(?:m)? ser\b", r"\bindica(?:do|cao)\b", r"\bcontraindica\b",
    r"\bduration of (?:therapy|treatment)\b", r"\bsource control\b",
    r"\bduracao (?:do )?tratamento\b",
]
GATILHOS_RE = re.compile("|".join(GATILHOS), re.IGNORECASE)


def extrair_heuristica(documento_id: int, texto: str, area: str | None) -> list[dict]:
    """Encontra frases candidatas (com gatilho) e devolve list of dicts."""
    frases = re.split(r"(?<=[.!?])\s+", texto)
    out: list[dict] = []
    for frase in frases:
        f = frase.strip()
        if 30 <= len(f) <= 400 and GATILHOS_RE.search(f):
            out.append({
                "documento_id": documento_id,
                "area": area,
                "recomendacao": f,
                "populacao": None,
                "conduta": None,
                "forca": _detect_forca(f),
                "qualidade": _detect_qualidade(f),
                "trecho_suporte": f,
                "referencia": None,
                "ano": None,
                "observacoes": "extracao heuristica",
            })
    return out


def _detect_forca(f: str) -> str:
    fl = f.lower()
    if re.search(r"\bstrong(ly)? recommend|forte\b", fl):
        return "forte"
    if "weak" in fl or "fraca" in fl or "condicional" in fl:
        return "fraca"
    if "should" in fl or "recommend" in fl or "recomenda" in fl:
        return "moderada"
    return "nao_informada"


def _detect_qualidade(f: str) -> str:
    fl = f.lower()
    if "high quality" in fl or "high certainty" in fl or "alta qualidade" in fl:
        return "alta"
    if "moderate quality" in fl or "moderate certainty" in fl:
        return "moderada"
    if "low quality" in fl or "low certainty" in fl or "baixa qualidade" in fl:
        return "baixa"
    if "very low" in fl or "muito baixa" in fl:
        return "muito_baixa"
    return "nao_informada"


def persistir(recs: list[dict]) -> int:
    n = 0
    for r in recs:
        db.insert_recommendation(r)
        n += 1
    return n


# --- LLM opcional ---------------------------------------------------------

LLM_SYSTEM = """Voce extrai recomendacoes clinicas estruturadas de um documento de infectologia.
Receba o TEXTO. Devolva APENAS um JSON array onde cada item tem as chaves:
  recomendacao, populacao, conduta, forca (forte|moderada|condicional|fraca|nao_informada),
  qualidade (alta|moderada|baixa|muito_baixa|nao_informada), trecho_suporte, referencia, ano, observacoes.
Nao invente. Quando uma chave nao estiver clara no texto, use string vazia (ou null para ano).
Ate 15 itens. Saida em portugues brasileiro. Sem markdown, sem comentarios fora do JSON.
"""


def llm_disponivel() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def extrair_llm(documento_id: int, texto: str, area: str | None, consentimento: bool) -> list[dict]:
    if not consentimento:
        raise PermissionError("Necessario consentimento explicito para enviar o texto ao LLM.")
    if not llm_disponivel():
        raise RuntimeError("ANTHROPIC_API_KEY ausente.")

    import json
    import anthropic
    client = anthropic.Anthropic()

    excerto = texto[:18000]
    msg = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=3000,
        system=LLM_SYSTEM,
        messages=[{"role": "user", "content": excerto}],
    )
    raw = ""
    for block in msg.content:
        if getattr(block, "type", None) == "text":
            raw += block.text
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        raw = raw.split("\n", 1)[1] if "\n" in raw else raw
        raw = raw.rstrip("`").strip()
    try:
        items = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if not isinstance(items, list):
        return []
    out: list[dict] = []
    for it in items[:30]:
        if not isinstance(it, dict) or not it.get("recomendacao"):
            continue
        out.append({
            "documento_id": documento_id,
            "area": area,
            "recomendacao": it.get("recomendacao") or "",
            "populacao": it.get("populacao"),
            "conduta": it.get("conduta"),
            "forca": it.get("forca") or "nao_informada",
            "qualidade": it.get("qualidade") or "nao_informada",
            "trecho_suporte": it.get("trecho_suporte"),
            "referencia": it.get("referencia"),
            "ano": it.get("ano"),
            "observacoes": (it.get("observacoes") or "") + " (LLM)",
        })
    return out
