"""Comparador heuristico entre protocolo local e evidencia nova/externa."""
from __future__ import annotations

from rapidfuzz import fuzz

from atualizador import db


STATUS = ["alinhado", "parcial", "divergente", "precisa_revisao", "insuficiente"]


def comparar_textos(tema: str, texto_local: str, texto_externo: str) -> dict:
    """Heuristica: similaridade textual + conflitos simples (dose, duracao, droga)."""
    if not texto_local.strip() or not texto_externo.strip():
        return {
            "tema": tema,
            "status": "insuficiente",
            "mudou": "",
            "impacto": "Sem texto suficiente para comparar.",
            "risco": "moderado",
            "sugestao": "Adicione conteudo (protocolo local + fonte externa) antes de comparar.",
            "referencias": "",
        }

    sim = fuzz.token_set_ratio(texto_local, texto_externo)
    diffs = _diffs_semanticos(texto_local, texto_externo)

    if sim >= 85 and not diffs:
        status, risco = "alinhado", "baixo"
    elif sim >= 65 and len(diffs) <= 2:
        status, risco = "parcial", "moderado"
    elif diffs:
        status, risco = "divergente", "alto"
    else:
        status, risco = "precisa_revisao", "moderado"

    mudou = "; ".join(d["descricao"] for d in diffs[:6]) or f"similaridade {sim}%"
    impacto = _formular_impacto(status, diffs)
    sugestao = _formular_sugestao(status, diffs)

    return {
        "tema": tema,
        "status": status,
        "mudou": mudou,
        "impacto": impacto,
        "risco": risco,
        "sugestao": sugestao,
        "referencias": "",
    }


def _diffs_semanticos(local: str, externo: str) -> list[dict]:
    import re
    diffs: list[dict] = []

    duracoes_local = set(re.findall(r"(\d{1,3})\s*dias?", local, re.IGNORECASE))
    duracoes_ext = set(re.findall(r"(\d{1,3})\s*(?:days|dias)", externo, re.IGNORECASE))
    so_local = duracoes_local - duracoes_ext
    so_ext = duracoes_ext - duracoes_local
    if so_local or so_ext:
        diffs.append({
            "tipo": "duracao",
            "descricao": f"duracoes diferentes (local: {so_local or '-'}, externo: {so_ext or '-'})",
        })

    drogas = ["ceftriaxone", "ceftriaxona", "meropenem", "ertapenem", "rifampin", "rifampicina",
              "vancomycin", "vancomicina", "linezolid", "daptomycin", "daptomicina",
              "dalbavancin", "dalbavancina", "fosfomycin", "fosfomicina"]
    presentes_local = {d for d in drogas if d in local.lower()}
    presentes_ext = {d for d in drogas if d in externo.lower()}
    so_local = presentes_local - presentes_ext
    so_ext = presentes_ext - presentes_local
    if so_local or so_ext:
        diffs.append({
            "tipo": "droga",
            "descricao": f"drogas exclusivas (local: {sorted(so_local) or '-'}, externo: {sorted(so_ext) or '-'})",
        })

    if "DAIR" in externo and "DAIR" not in local:
        diffs.append({"tipo": "estrategia", "descricao": "externo cita DAIR; protocolo local nao menciona"})

    return diffs


def _formular_impacto(status: str, diffs: list[dict]) -> str:
    if status == "alinhado":
        return "Protocolo local segue alinhado com a referencia externa. Sem alteracao necessaria."
    if status == "parcial":
        return "Protocolo local cobre o tema mas com pequenas divergencias. Avaliar atualizacao do texto."
    if status == "divergente":
        tipos = ", ".join({d["tipo"] for d in diffs})
        return f"Divergencias relevantes em: {tipos}. Revisar conduta antes da proxima atualizacao."
    if status == "precisa_revisao":
        return "Texto local parece desatualizado; recomendado revisao manual."
    return "Sem dados suficientes para concluir."


def _formular_sugestao(status: str, diffs: list[dict]) -> str:
    if status == "alinhado":
        return "Nenhuma acao necessaria."
    if status == "parcial":
        return "Atualizar pontos de divergencia, manter estrutura."
    if status == "divergente":
        return "Reescrever sessoes divergentes e avaliar com equipe."
    if status == "precisa_revisao":
        return "Marcar protocolo para revisao manual."
    return "Adicionar fonte externa antes de concluir."


def persistir(comp: dict, doc_local_id: int | None = None, fonte_desc: str | None = None) -> int:
    payload = {
        **comp,
        "doc_local_id": doc_local_id,
        "fonte_nova_desc": fonte_desc,
    }
    return db.insert_comparison(payload)
