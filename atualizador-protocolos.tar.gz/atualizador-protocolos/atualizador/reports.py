"""Relatorios: semanal, mensal, por tema."""
from __future__ import annotations

import os
from datetime import date, datetime
from pathlib import Path

from atualizador import db

EXPORT_DIR = Path(__file__).resolve().parent.parent / "exports"


def garantir_dir() -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    return EXPORT_DIR


def _idade_meses(data_str: str | None) -> int | None:
    if not data_str:
        return None
    try:
        d = datetime.fromisoformat(data_str[:10])
    except ValueError:
        return None
    diff = (date.today() - d.date()).days
    return diff // 30


def relatorio_revisao_mensal() -> str:
    threshold = int(os.environ.get("PROTOCOL_AGE_THRESHOLD_MONTHS", "18"))
    docs = db.list_documents()
    if not docs:
        return f"# Revisao de protocolos - {date.today().isoformat()}\n\nNenhum documento na base."

    antigos: list[dict] = []
    recentes: list[dict] = []
    sem_data: list[dict] = []
    for d in docs:
        meses = _idade_meses(d.get("data_doc"))
        if meses is None:
            sem_data.append(d)
        elif meses >= threshold:
            antigos.append({**d, "idade_meses": meses})
        else:
            recentes.append({**d, "idade_meses": meses})

    comps = db.list_comparisons()
    a_revisar = [c for c in comps if c["status"] in {"divergente", "precisa_revisao"}]

    linhas = [
        f"# Revisao de protocolos - {date.today().isoformat()}",
        f"\nThreshold para 'antigo': {threshold} meses.\n",
        f"- Total na base: **{len(docs)}**",
        f"- Recentes: {len(recentes)}",
        f"- Antigos (>= {threshold} meses): **{len(antigos)}**",
        f"- Sem data identificavel: {len(sem_data)}",
        f"- Comparacoes pendentes de revisao: **{len(a_revisar)}**",
        "",
        "## Antigos",
    ]
    if not antigos:
        linhas.append("- (nenhum)")
    for d in sorted(antigos, key=lambda x: -x["idade_meses"]):
        linhas.append(f"- **{d['titulo']}** - area {d.get('area')} - {d['idade_meses']} meses")

    linhas += ["", "## Comparacoes que precisam revisao"]
    if not a_revisar:
        linhas.append("- (nenhuma)")
    for c in a_revisar:
        linhas.append(f"- **{c['tema']}** - status {c['status']} - risco {c['risco']}")

    linhas += ["", "## Sem data identificavel"]
    if not sem_data:
        linhas.append("- (nenhum)")
    for d in sem_data:
        linhas.append(f"- {d['titulo']} ({d.get('tipo')}, area {d.get('area')})")

    return "\n".join(linhas)


def relatorio_por_tema(tema: str) -> str:
    docs = db.list_documents()
    relacionados = [d for d in docs if tema.lower() in (d.get("titulo") or "").lower()
                    or tema.lower() in (d.get("texto_completo") or "").lower()[:5000]]
    comps = [c for c in db.list_comparisons() if tema.lower() in c["tema"].lower()]
    linhas = [
        f"# Atualizacao em {tema} - {date.today().strftime('%B de %Y')}",
        "",
        "## Resumo executivo",
        f"Encontrei {len(relacionados)} documento(s) na base e {len(comps)} comparacao(oes) relacionadas a '{tema}'.",
        "",
        "## Documentos locais relacionados",
    ]
    if not relacionados:
        linhas.append("- (nenhum)")
    for d in relacionados[:15]:
        linhas.append(f"- **{d['titulo']}** ({d.get('tipo')}, {d.get('area')}, {d.get('data_doc') or 'sem data'})")

    linhas += ["", "## Comparacoes salvas"]
    if not comps:
        linhas.append("- (nenhuma)")
    for c in comps:
        linhas.append(f"- **status {c['status']}** ({c['risco']} risco) - {c['mudou']}")

    linhas += [
        "",
        "## Recomendacoes praticas",
        "- Sempre confronte estas notas com o documento original antes de mudar conduta.",
        "- Marque um item como 'precisa revisao' se identificar divergencia.",
    ]
    return "\n".join(linhas)


def salvar_md(conteudo: str, tipo: str) -> Path:
    pasta = garantir_dir()
    nome = f"relatorio-{tipo}-{date.today().isoformat()}.md"
    p = pasta / nome
    p.write_text(conteudo, encoding="utf-8")
    with db.connect() as conn:
        conn.execute(
            "INSERT INTO update_reports (tipo, periodo, caminho, criado_em) VALUES (?, ?, ?, ?)",
            (tipo, date.today().isoformat(), str(p), datetime.now().isoformat(timespec="seconds")),
        )
    return p


def salvar_docx(conteudo: str, tipo: str) -> Path:
    from docx import Document
    pasta = garantir_dir()
    doc = Document()
    for linha in conteudo.splitlines():
        if linha.startswith("# "):
            doc.add_heading(linha[2:], 1)
        elif linha.startswith("## "):
            doc.add_heading(linha[3:], 2)
        elif linha.startswith("### "):
            doc.add_heading(linha[4:], 3)
        elif linha.startswith("- "):
            doc.add_paragraph(linha[2:], style="List Bullet")
        else:
            doc.add_paragraph(linha)
    p = pasta / f"relatorio-{tipo}-{date.today().isoformat()}.docx"
    doc.save(str(p))
    return p
