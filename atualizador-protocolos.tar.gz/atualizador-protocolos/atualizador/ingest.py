"""Ingestao de documentos: PDF, DOCX, MD, TXT -> banco SQLite."""
from __future__ import annotations

import hashlib
import re
from datetime import datetime
from pathlib import Path

from atualizador import db

AREAS = [
    "Ortoinfectologia", "Antimicrobianos", "Bacteremias", "Endocardite",
    "ITU", "Pneumonia", "Infeccao abdominal", "HIV", "Imunocomprometidos",
    "Clostridioides difficile", "OPAT/PAD", "Stewardship", "Fungos",
    "Tuberculose", "Outros",
]

KEYWORDS_AREA = {
    "Ortoinfectologia": ["prothesi", "joint infection", "PJI", "DAIR", "osteomyelit", "septic arthrit",
                          "fracture related infection", "implant", "rifampin"],
    "HIV": ["HIV", "antiretroviral", "PrEP", "ARV"],
    "Clostridioides difficile": ["C. difficile", "C difficile", "Clostridioides", "fidaxomicin"],
    "OPAT/PAD": ["OPAT", "outpatient parenteral", "home infusion", "PAD"],
    "Antimicrobianos": ["beta-lactam", "carbapenem", "cefiderocol", "vancomycin AUC", "stewardship"],
    "Bacteremias": ["bacteremia", "bacteraemia", "bloodstream infection", "endocarditis"],
    "ITU": ["urinary tract infection", "pyelonephritis", "ESBL UTI"],
    "Pneumonia": ["pneumonia", "HAP", "VAP", "CAP"],
    "Fungos": ["candidemia", "aspergillus", "candidiasis", "antifungal"],
    "Tuberculose": ["tuberculosis", "TB", "tuberculose"],
    "Imunocomprometidos": ["neutropenic fever", "febrile neutropenia", "transplant"],
}


def _hash_file(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def _extract_pdf(p: Path) -> tuple[str, int]:
    import fitz  # pymupdf
    with fitz.open(p) as doc:
        textos = [page.get_text() for page in doc]
        return "\n\n".join(textos), len(doc)


def _extract_docx(p: Path) -> tuple[str, int]:
    from docx import Document
    doc = Document(str(p))
    paragraphs = [par.text for par in doc.paragraphs]
    return "\n".join(paragraphs), len(paragraphs)


def _extract_text(p: Path) -> tuple[str, int]:
    txt = p.read_text(encoding="utf-8", errors="ignore")
    return txt, len(txt.splitlines())


def detectar_area(texto: str) -> str:
    blob = texto.lower()
    melhor = "Outros"
    melhor_hits = 0
    for area, kws in KEYWORDS_AREA.items():
        hits = sum(1 for k in kws if k.lower() in blob)
        if hits > melhor_hits:
            melhor_hits = hits
            melhor = area
    return melhor


_RE_VERSAO = re.compile(r"\b(vers[aã]o|version)\s*[:\-]?\s*([\w.\-]+)", re.IGNORECASE)
_RE_DATA = re.compile(r"\b((?:19|20)\d{2})[-/](\d{1,2})[-/](\d{1,2})\b")
_RE_DATA2 = re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-]((?:19|20)\d{2})\b")
_RE_ANO = re.compile(r"\b(19|20)\d{2}\b")


def detectar_data(texto: str) -> str | None:
    for m in _RE_DATA.finditer(texto[:3000]):
        try:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            return f"{y:04d}-{mo:02d}-{d:02d}"
        except ValueError:
            continue
    for m in _RE_DATA2.finditer(texto[:3000]):
        try:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            return f"{y:04d}-{mo:02d}-{d:02d}"
        except ValueError:
            continue
    m = _RE_ANO.search(texto[:3000])
    if m:
        return m.group(0) + "-01-01"
    return None


def detectar_versao(texto: str) -> str | None:
    m = _RE_VERSAO.search(texto[:3000])
    return m.group(2) if m else None


def detectar_tipo(p: Path, texto: str) -> str:
    nome = p.name.lower()
    blob = texto[:5000].lower()
    if "guideline" in blob or "recommendation" in blob or "consensus" in blob:
        return "guideline"
    if "protocolo" in nome or "protocol" in nome or "padronizacao" in nome:
        return "protocolo_local"
    if p.suffix.lower() == ".md" or p.suffix.lower() == ".txt":
        return "anotacao"
    if "abstract" in blob and len(texto) < 12000:
        return "artigo"
    return "outro"


def chunk_text(texto: str, max_chars: int = 1800) -> list[str]:
    """Quebra em chunks por paragrafo, respeitando max_chars."""
    out: list[str] = []
    buffer = ""
    for par in re.split(r"\n{2,}", texto):
        par = par.strip()
        if not par:
            continue
        if len(buffer) + len(par) + 2 < max_chars:
            buffer += ("\n\n" + par) if buffer else par
        else:
            if buffer:
                out.append(buffer)
            if len(par) > max_chars:
                for i in range(0, len(par), max_chars):
                    out.append(par[i:i + max_chars])
                buffer = ""
            else:
                buffer = par
    if buffer:
        out.append(buffer)
    return out


def ingest_file(path: Path) -> int:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    suf = p.suffix.lower()
    if suf == ".pdf":
        texto, paginas = _extract_pdf(p)
    elif suf == ".docx":
        texto, paginas = _extract_docx(p)
    elif suf in {".md", ".txt"}:
        texto, paginas = _extract_text(p)
    else:
        raise ValueError(f"Formato nao suportado: {suf}")

    h = _hash_file(p)
    titulo = p.stem.replace("_", " ").replace("-", " ")
    primeira_linha = next((l.strip() for l in texto.splitlines() if l.strip()), titulo)
    if 10 <= len(primeira_linha) <= 200:
        titulo = primeira_linha

    area = detectar_area(texto)
    data_doc = detectar_data(texto)
    versao = detectar_versao(texto)
    tipo = detectar_tipo(p, texto)

    doc_id = db.upsert_document({
        "caminho": str(p.resolve()),
        "titulo": titulo,
        "tipo": tipo,
        "fonte": None,
        "versao": versao,
        "data_doc": data_doc,
        "area": area,
        "hash": h,
        "paginas": paginas,
        "resumo": (texto[:1000] + "...") if len(texto) > 1000 else texto,
        "texto_completo": texto,
    })

    chunks = chunk_text(texto)
    db.add_chunks(doc_id, [{"ordem": i, "texto": t, "pagina": None} for i, t in enumerate(chunks)])
    db.log("ingest", {"doc_id": doc_id, "path": str(p), "chunks": len(chunks)})
    return doc_id


def ingest_dir(folder: Path) -> dict:
    f = Path(folder)
    if not f.exists():
        return {"inseridos": 0, "erros": [f"pasta nao existe: {f}"]}
    inseridos = 0
    erros: list[str] = []
    for p in f.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".pdf", ".docx", ".md", ".txt"}:
            try:
                ingest_file(p)
                inseridos += 1
            except Exception as e:
                erros.append(f"{p}: {e}")
    return {"inseridos": inseridos, "erros": erros}
