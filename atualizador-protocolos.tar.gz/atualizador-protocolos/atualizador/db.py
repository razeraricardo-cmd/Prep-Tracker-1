"""SQLite schema do Atualizador."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "atualizador.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  caminho TEXT NOT NULL UNIQUE,
  titulo TEXT NOT NULL,
  tipo TEXT,                       -- guideline | protocolo_local | artigo | anotacao | outro
  fonte TEXT,                      -- IDSA, ESCMID, institucional, ...
  versao TEXT,
  data_doc TEXT,                   -- data identificavel no doc
  area TEXT,
  hash TEXT,
  ingestao TEXT NOT NULL,          -- ISO timestamp
  paginas INTEGER,
  resumo TEXT,
  texto_completo TEXT
);

CREATE INDEX IF NOT EXISTS idx_doc_area ON documents(area);
CREATE INDEX IF NOT EXISTS idx_doc_tipo ON documents(tipo);
CREATE INDEX IF NOT EXISTS idx_doc_data ON documents(data_doc);

CREATE TABLE IF NOT EXISTS document_chunks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  documento_id INTEGER NOT NULL,
  ordem INTEGER NOT NULL,
  texto TEXT NOT NULL,
  pagina INTEGER,
  FOREIGN KEY (documento_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_chunk_doc ON document_chunks(documento_id);

CREATE TABLE IF NOT EXISTS recommendations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  documento_id INTEGER NOT NULL,
  area TEXT,
  recomendacao TEXT NOT NULL,
  populacao TEXT,
  conduta TEXT,
  forca TEXT,                      -- forte | moderada | condicional | fraca | nao_informada
  qualidade TEXT,                  -- alta | moderada | baixa | muito_baixa | nao_informada
  trecho_suporte TEXT,
  referencia TEXT,
  ano TEXT,
  observacoes TEXT,
  criado_em TEXT NOT NULL,
  FOREIGN KEY (documento_id) REFERENCES documents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_rec_area ON recommendations(area);
CREATE INDEX IF NOT EXISTS idx_rec_doc ON recommendations(documento_id);

CREATE TABLE IF NOT EXISTS protocol_comparisons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tema TEXT NOT NULL,
  doc_local_id INTEGER,
  fonte_nova_desc TEXT,
  status TEXT NOT NULL,            -- alinhado | parcial | divergente | precisa_revisao | insuficiente
  mudou TEXT,
  impacto TEXT,
  risco TEXT,                      -- baixo | moderado | alto
  sugestao TEXT,
  referencias TEXT,
  criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS update_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo TEXT NOT NULL,              -- semanal | mensal | tema
  periodo TEXT NOT NULL,
  caminho TEXT NOT NULL,
  criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  acao TEXT NOT NULL,
  detalhe TEXT
);
"""


def db_path() -> Path:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return DB_PATH


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def log(acao: str, detalhe: str | dict | None = None) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO audit_log (ts, acao, detalhe) VALUES (?, ?, ?)",
            (_now(), acao, json.dumps(detalhe, ensure_ascii=False) if isinstance(detalhe, dict) else detalhe),
        )


def upsert_document(doc: dict) -> int:
    """Insere/atualiza por caminho. Retorna id."""
    with connect() as conn:
        existing = conn.execute(
            "SELECT id, hash FROM documents WHERE caminho = ?", (doc["caminho"],)
        ).fetchone()
        if existing:
            doc_id = existing["id"]
            if existing["hash"] != doc.get("hash"):
                conn.execute(
                    """UPDATE documents SET titulo=?, tipo=?, fonte=?, versao=?, data_doc=?,
                       area=?, hash=?, ingestao=?, paginas=?, resumo=?, texto_completo=?
                       WHERE id=?""",
                    (
                        doc.get("titulo"), doc.get("tipo"), doc.get("fonte"), doc.get("versao"),
                        doc.get("data_doc"), doc.get("area"), doc.get("hash"), _now(),
                        doc.get("paginas"), doc.get("resumo"), doc.get("texto_completo"),
                        doc_id,
                    ),
                )
                conn.execute("DELETE FROM document_chunks WHERE documento_id = ?", (doc_id,))
            return doc_id
        cur = conn.execute(
            """INSERT INTO documents (caminho, titulo, tipo, fonte, versao, data_doc, area,
                hash, ingestao, paginas, resumo, texto_completo)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                doc["caminho"], doc.get("titulo") or doc["caminho"], doc.get("tipo"),
                doc.get("fonte"), doc.get("versao"), doc.get("data_doc"), doc.get("area"),
                doc.get("hash"), _now(), doc.get("paginas"),
                doc.get("resumo"), doc.get("texto_completo"),
            ),
        )
        return cur.lastrowid


def add_chunks(doc_id: int, chunks: list[dict]) -> None:
    with connect() as conn:
        conn.executemany(
            "INSERT INTO document_chunks (documento_id, ordem, texto, pagina) VALUES (?, ?, ?, ?)",
            [(doc_id, c["ordem"], c["texto"], c.get("pagina")) for c in chunks],
        )


def list_documents(area: str | None = None, tipo: str | None = None) -> list[dict]:
    sql = "SELECT * FROM documents WHERE 1=1"
    params: list = []
    if area:
        sql += " AND area = ?"
        params.append(area)
    if tipo:
        sql += " AND tipo = ?"
        params.append(tipo)
    sql += " ORDER BY ingestao DESC"
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def get_document(doc_id: int) -> dict | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    return dict(row) if row else None


def delete_document(doc_id: int) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))


def all_chunks() -> list[dict]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT c.*, d.titulo, d.tipo, d.area FROM document_chunks c "
            "JOIN documents d ON d.id = c.documento_id"
        ).fetchall()
    return [dict(r) for r in rows]


def insert_recommendation(rec: dict) -> int:
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO recommendations
               (documento_id, area, recomendacao, populacao, conduta, forca, qualidade,
                trecho_suporte, referencia, ano, observacoes, criado_em)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                rec["documento_id"], rec.get("area"), rec["recomendacao"],
                rec.get("populacao"), rec.get("conduta"), rec.get("forca"), rec.get("qualidade"),
                rec.get("trecho_suporte"), rec.get("referencia"), rec.get("ano"),
                rec.get("observacoes"), _now(),
            ),
        )
        return cur.lastrowid


def list_recommendations(documento_id: int | None = None, area: str | None = None) -> list[dict]:
    sql = "SELECT r.*, d.titulo as documento_titulo FROM recommendations r JOIN documents d ON d.id = r.documento_id WHERE 1=1"
    params: list = []
    if documento_id:
        sql += " AND r.documento_id = ?"
        params.append(documento_id)
    if area:
        sql += " AND r.area = ?"
        params.append(area)
    sql += " ORDER BY r.criado_em DESC"
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def insert_comparison(comp: dict) -> int:
    with connect() as conn:
        cur = conn.execute(
            """INSERT INTO protocol_comparisons
               (tema, doc_local_id, fonte_nova_desc, status, mudou, impacto, risco, sugestao, referencias, criado_em)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                comp["tema"], comp.get("doc_local_id"), comp.get("fonte_nova_desc"),
                comp["status"], comp.get("mudou"), comp.get("impacto"),
                comp.get("risco"), comp.get("sugestao"), comp.get("referencias"), _now(),
            ),
        )
        return cur.lastrowid


def list_comparisons() -> list[dict]:
    with connect() as conn:
        rows = conn.execute("SELECT * FROM protocol_comparisons ORDER BY criado_em DESC").fetchall()
    return [dict(r) for r in rows]
