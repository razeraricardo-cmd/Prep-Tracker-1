"""Busca local nos chunks via fuzzy + bag-of-words. Sem dependencias pesadas."""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Iterable

from rapidfuzz import fuzz

from atualizador import db

STOPWORDS = {
    "the", "and", "of", "to", "in", "is", "for", "with", "or", "a", "an", "that",
    "de", "da", "do", "das", "dos", "e", "em", "para", "com", "ou", "uma", "um",
    "no", "na", "nos", "nas", "que", "se",
}


def _tokens(s: str) -> list[str]:
    return [t for t in re.findall(r"[a-zA-Z][a-zA-Z]+", (s or "").lower()) if t not in STOPWORDS]


def search_chunks(query: str, top_k: int = 8) -> list[dict]:
    if not query.strip():
        return []
    chunks = db.all_chunks()
    if not chunks:
        return []

    q_tokens = _tokens(query)
    q_count = Counter(q_tokens)

    # IDF aproximado
    n_docs = len(chunks)
    df: Counter[str] = Counter()
    for c in chunks:
        df.update(set(_tokens(c["texto"])))
    idf = {t: math.log((n_docs + 1) / (df[t] + 1)) + 1 for t in q_count}

    scored: list[tuple[float, dict]] = []
    for c in chunks:
        toks = _tokens(c["texto"])
        if not toks:
            continue
        tf = Counter(toks)
        bm = sum((tf[t] * idf.get(t, 0)) for t in q_count)
        fz = fuzz.token_set_ratio(query, c["texto"][:600]) / 100.0
        score = bm + fz * 2
        if score <= 0:
            continue
        scored.append((score, c))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [{"score": s, **c} for s, c in scored[:top_k]]


def search_excerpt(chunk_texto: str, query: str, ctx: int = 240) -> str:
    """Retorna trecho do chunk com a query destacada por '...'."""
    if not chunk_texto:
        return ""
    toks = _tokens(query)
    if not toks:
        return chunk_texto[:ctx * 2]
    pos = -1
    for t in toks:
        idx = chunk_texto.lower().find(t)
        if idx >= 0 and (pos == -1 or idx < pos):
            pos = idx
    if pos < 0:
        return chunk_texto[:ctx * 2]
    start = max(0, pos - ctx)
    end = min(len(chunk_texto), pos + ctx)
    out = chunk_texto[start:end]
    if start > 0:
        out = "..." + out
    if end < len(chunk_texto):
        out = out + "..."
    return out
