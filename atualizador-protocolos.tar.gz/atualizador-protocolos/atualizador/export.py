"""Exportacao XLSX e listas para o Atualizador."""
from __future__ import annotations

from io import BytesIO

import pandas as pd

from atualizador import db


def recomendacoes_xlsx() -> bytes:
    recs = db.list_recommendations()
    df = pd.DataFrame(recs) if recs else pd.DataFrame(columns=["recomendacao"])
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="recomendacoes", index=False)
    return buf.getvalue()


def documentos_xlsx() -> bytes:
    docs = db.list_documents()
    df = pd.DataFrame(docs) if docs else pd.DataFrame(columns=["titulo"])
    if "texto_completo" in df.columns:
        df = df.drop(columns=["texto_completo"])
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="documentos", index=False)
    return buf.getvalue()
