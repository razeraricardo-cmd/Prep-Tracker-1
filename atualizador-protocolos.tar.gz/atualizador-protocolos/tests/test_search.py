from atualizador import db, search


def setup_module(_):
    db.init_db()


def test_busca_vazia_retorna_lista_vazia():
    assert search.search_chunks("") == []


def test_excerpt_destaca_em_torno_da_query():
    txt = "abacaxi laranja banana uva manga melao pera kiwi morango caqui"
    out = search.search_excerpt(txt, "manga", ctx=10)
    assert "manga" in out
