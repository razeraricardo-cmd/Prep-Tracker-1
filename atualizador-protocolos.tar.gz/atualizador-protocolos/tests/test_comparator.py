from atualizador.comparator import comparar_textos


def test_alinhado_quando_textos_semelhantes():
    local = "Tratar bacteremia por S aureus com cefazolina por 14 dias. Avaliar source control."
    externo = "S. aureus bacteremia should be treated with cefazolin for 14 days with source control."
    comp = comparar_textos("S aureus bacteremia", local, externo)
    assert comp["status"] in {"alinhado", "parcial"}


def test_divergencia_em_duracao_dispara_revisao():
    local = "Tratar por 7 dias."
    externo = "Treat for 14 days based on recent trial."
    comp = comparar_textos("duracao", local, externo)
    assert comp["status"] in {"divergente", "precisa_revisao", "parcial"}
    assert any(k in comp["mudou"] for k in ("duracoes", "duracao", "similaridade"))


def test_insuficiente_quando_falta_texto():
    comp = comparar_textos("x", "", "qualquer coisa")
    assert comp["status"] == "insuficiente"
