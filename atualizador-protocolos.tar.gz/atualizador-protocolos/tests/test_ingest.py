from atualizador.ingest import chunk_text, detectar_area, detectar_data, detectar_versao, detectar_tipo
from pathlib import Path


def test_chunk_quebra_paragrafos():
    txt = "a" * 1000 + "\n\n" + "b" * 1000 + "\n\n" + "c" * 1000
    chunks = chunk_text(txt, max_chars=1800)
    # cabe um por chunk com max 1800; pode reagrupar 2 em 1 chunk
    assert all(len(c) <= 1800 for c in chunks)
    assert "".join(chunks).count("a") == 1000


def test_detecta_area_orto():
    txt = "Patients with prosthetic joint infection (PJI) managed with DAIR and rifampin..."
    assert detectar_area(txt) == "Ortoinfectologia"


def test_detecta_data_iso():
    assert detectar_data("Publicado em 2024-05-12 pela sociedade") == "2024-05-12"


def test_detecta_data_brasileira():
    assert detectar_data("Data 12/05/2024") == "2024-05-12"


def test_versao():
    assert detectar_versao("Versao: 3.1 do protocolo") == "3.1"


def test_tipo_protocolo_local():
    p = Path("protocolo-pji.pdf")
    assert detectar_tipo(p, "Protocolo institucional") == "protocolo_local"


def test_tipo_guideline():
    p = Path("idsa.pdf")
    assert detectar_tipo(p, "This guideline provides recommendations...") == "guideline"
