"""Radar de Evidencias - entry Streamlit."""
from __future__ import annotations

import streamlit as st

from radar.db import init_db

st.set_page_config(
    page_title="Radar de Evidencias - Infectologia",
    page_icon=":mag:",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()

st.title("Radar de Evidencias - Infectologia")
st.markdown(
    """
Aplicacao local que busca novidades cientificas em PubMed, RSS de journals/sociedades,
ClinicalTrials.gov e preprints; classifica, deduplica e prioriza por relevancia clinica
para minha pratica em infectologia, ortoinfectologia, OPAT/PAD e imunocomprometidos.

Use a barra lateral para navegar:
- **Dashboard** - totais, alta prioridade, novos do dia
- **Novidades** - tabela com filtros e marcacao (relevante, salvo, ignorado, practice changing)
- **Buscar manualmente** - pergunta livre ao PubMed
- **Boletins** - gerar/exportar diario, semanal, mensal
- **Configuracoes** - editar areas, keywords e fontes
"""
)

st.info(
    "Este sistema **nao substitui leitura critica**. Resumos heuristicos ou via IA "
    "nao validam metodologia. Sempre leia o estudo antes de mudar conduta.",
    icon=":warning:",
)
st.caption("Dados locais em data/radar.db. Use NCBI_EMAIL no .env para respeitar a politica do PubMed.")
