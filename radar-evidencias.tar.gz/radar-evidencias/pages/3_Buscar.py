from __future__ import annotations

import streamlit as st

from radar import fetcher

st.set_page_config(page_title="Buscar manualmente", page_icon=":mag_right:", layout="wide")
st.title("Buscar manualmente")

st.write("Faca uma pergunta livre. A consulta vai para o PubMed; ranking heuristico usa as suas areas/keywords.")

q = st.text_input("Pergunta / termos", placeholder="ex: duracao de tratamento bacteremia gram negativo")
c1, c2 = st.columns(2)
dias = c1.number_input("Janela (dias)", min_value=1, max_value=365, value=180)
retmax = c2.number_input("Maximo de resultados", min_value=5, max_value=200, value=30)

if st.button("Buscar", type="primary", disabled=not q.strip()):
    with st.spinner("Buscando no PubMed..."):
        novos = fetcher.run_pubmed(q, dias=int(dias), retmax=int(retmax))
    st.success(f"{novos} item(ns) novo(s) indexado(s). Va em **Novidades** para revisar.")
