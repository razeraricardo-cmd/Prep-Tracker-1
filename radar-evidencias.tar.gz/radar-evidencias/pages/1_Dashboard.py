from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import streamlit as st

from radar import db, config

st.set_page_config(page_title="Dashboard - Radar", page_icon=":bar_chart:", layout="wide")
st.title("Dashboard")

cfg = config.scoring_cfg()
limiar = int(cfg.get("limiar_alerta", 60))

hoje = date.today()
ontem = (hoje - timedelta(days=1)).isoformat()
semana = (hoje - timedelta(days=7)).isoformat()

todos = db.list_articles(limit=100000)
df = pd.DataFrame(todos)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total na base", len(df))
c2.metric("Ultimas 24h", 0 if df.empty else int((df["data_pub"] >= ontem).fillna(False).sum()))
c3.metric("Ultima semana", 0 if df.empty else int((df["data_pub"] >= semana).fillna(False).sum()))
c4.metric(f"Score >= {limiar}", 0 if df.empty else int((df["score"] >= limiar).sum()))

if df.empty:
    st.info("Nenhum artigo. Va em **Configuracoes / Buscar manualmente** para rodar uma busca inicial.")
    st.stop()

st.subheader("Por area")
st.bar_chart(df["area"].fillna("(sem area)").value_counts())

st.subheader("Por tipo de evidencia")
st.bar_chart(df["tipo_evidencia"].fillna("(nao classificado)").value_counts())

st.subheader("Top 10 por score")
top = df.sort_values(["score", "data_pub"], ascending=[False, False]).head(10)
st.dataframe(
    top[["score", "titulo", "journal", "tipo_evidencia", "area", "data_pub", "fonte"]],
    use_container_width=True,
    hide_index=True,
)

st.subheader("Practice-changing salvos")
pc = df[df["status"] == "practice"]
if pc.empty:
    st.caption("Nenhum item marcado como practice-changing ainda.")
else:
    st.dataframe(pc[["titulo", "journal", "score", "link"]], use_container_width=True, hide_index=True)
