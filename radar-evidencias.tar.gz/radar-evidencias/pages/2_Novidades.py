from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import streamlit as st

from radar import config, db, fetcher

st.set_page_config(page_title="Novidades", page_icon=":newspaper:", layout="wide")
st.title("Novidades")

with st.expander("Rodar busca agora", expanded=False):
    c1, c2 = st.columns(2)
    dias = c1.number_input("Janela (dias)", min_value=1, max_value=365, value=int(config.geral().get("janela_dias_busca", 30)))
    retmax = c2.number_input("Maximo por keyword (PubMed)", min_value=5, max_value=200, value=25)
    if st.button("Buscar agora (PubMed + RSS + ClinicalTrials + preprints)", type="primary"):
        with st.spinner("Buscando..."):
            res = fetcher.run_all_areas(dias=int(dias), retmax_por_query=int(retmax))
        st.success(f"OK: {res}")

with st.expander("Filtros", expanded=True):
    c1, c2, c3, c4 = st.columns(4)
    areas = config.areas()
    area_sel = c1.selectbox("Area", [""] + list(areas.keys()))
    status_sel = c2.selectbox("Status", ["", "novo", "relevante", "lido", "ignorado", "salvo", "practice", "apresentar"])
    score_min = c3.slider("Score minimo", 0, 100, 0, step=5)
    janela_d = c4.number_input("Ultimos N dias", min_value=1, max_value=365, value=30)

artigos = db.list_articles(
    area=area_sel or None,
    status=status_sel or None,
    score_min=int(score_min) if score_min else None,
    desde=(date.today() - timedelta(days=int(janela_d))).isoformat(),
    limit=2000,
)

st.caption(f"{len(artigos)} resultado(s).")

if artigos:
    df = pd.DataFrame(artigos)
    cols = ["id", "score", "titulo", "journal", "tipo_evidencia", "area", "fonte", "data_pub", "status"]
    st.dataframe(df[cols], use_container_width=True, hide_index=True)

    sel = st.selectbox("Detalhar/marcar artigo", options=[None] + [a["id"] for a in artigos],
                        format_func=lambda x: "" if x is None else f"#{x}")
    if sel:
        a = db.get_article(int(sel))
        if a:
            st.markdown(f"### {a['titulo']}")
            st.write(f"**Fonte:** {a.get('fonte')} - **Journal:** {a.get('journal')} - **Data:** {a.get('data_pub')}")
            st.write(f"**Tipo:** {a.get('tipo_evidencia')} - **Area:** {a.get('area')} - **Score:** {a.get('score')}/100")
            st.write(f"**Link:** {a.get('link') or '(sem link)'}")
            st.text_area("Abstract", value=a.get("abstract") or "", height=220, disabled=True)
            obs = st.text_area("Observacoes", value=a.get("observacoes") or "", height=100)
            novo_status = st.selectbox(
                "Status",
                ["novo", "relevante", "lido", "ignorado", "salvo", "practice", "apresentar"],
                index=["novo", "relevante", "lido", "ignorado", "salvo", "practice", "apresentar"].index(a.get("status") or "novo"),
            )
            colA, colB, colC = st.columns(3)
            if colA.button("Salvar"):
                db.update_article(int(sel), {"status": novo_status, "observacoes": obs})
                st.success("Salvo.")
                st.rerun()
            if colB.button("Apagar definitivamente"):
                if st.session_state.get(f"confdel_{sel}"):
                    db.delete_article(int(sel))
                    st.success("Apagado.")
                    st.rerun()
                else:
                    st.session_state[f"confdel_{sel}"] = True
                    st.warning("Clique novamente para confirmar.")
            try:
                from radar import llm
                if llm.disponivel() and colC.checkbox("Gerar resumo critico via IA (opt-in)"):
                    if colC.button("Gerar resumo critico"):
                        with st.spinner("Resumindo..."):
                            r = llm.resumir(a.get("titulo", ""), a.get("abstract", ""), a.get("fonte") == "preprint")
                        db.update_article(int(sel), {"resumo_critico": r})
                        st.code(r)
            except Exception as e:
                st.caption(f"IA indisponivel: {e}")
