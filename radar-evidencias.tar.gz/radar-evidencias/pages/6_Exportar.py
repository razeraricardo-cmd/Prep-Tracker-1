from __future__ import annotations

from datetime import date

import streamlit as st

from radar import db, export

st.set_page_config(page_title="Exportar - Radar", page_icon=":outbox_tray:", layout="wide")
st.title("Exportar")

artigos = db.list_articles(limit=100000)
st.caption(f"{len(artigos)} artigo(s) na base.")

c1, c2, c3 = st.columns(3)
c1.download_button(
    "XLSX completo",
    data=export.to_xlsx(artigos),
    file_name=f"radar-{date.today().isoformat()}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)
c2.download_button(
    "BibTeX",
    data=export.to_bibtex(artigos).encode("utf-8"),
    file_name=f"radar-{date.today().isoformat()}.bib",
    mime="text/x-bibtex",
)
c3.download_button(
    "RIS",
    data=export.to_ris(artigos).encode("utf-8"),
    file_name=f"radar-{date.today().isoformat()}.ris",
    mime="application/x-research-info-systems",
)
