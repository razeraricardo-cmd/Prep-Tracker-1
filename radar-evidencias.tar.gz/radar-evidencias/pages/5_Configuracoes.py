from __future__ import annotations

from pathlib import Path

import streamlit as st
import yaml

from radar.config import CONFIG_PATH, load

st.set_page_config(page_title="Configuracoes", page_icon=":gear:", layout="wide")
st.title("Configuracoes")

st.caption("Edite config.yaml. As alteracoes ficam salvas em disco e recarregam na proxima execucao.")

cfg = load()
raw = CONFIG_PATH.read_text(encoding="utf-8") if CONFIG_PATH.exists() else ""

novo = st.text_area("config.yaml", value=raw, height=600)
if st.button("Salvar config.yaml", type="primary"):
    try:
        yaml.safe_load(novo)  # valida sintaxe
        CONFIG_PATH.write_text(novo, encoding="utf-8")
        load.cache_clear()  # type: ignore[attr-defined]
        st.success("config.yaml salvo.")
    except Exception as e:
        st.error(f"YAML invalido: {e}")
