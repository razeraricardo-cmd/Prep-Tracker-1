from __future__ import annotations

import streamlit as st

from radar import bulletin

st.set_page_config(page_title="Boletins", page_icon=":scroll:", layout="wide")
st.title("Boletins")

tab_diario, tab_sem, tab_mes = st.tabs(["Diario", "Semanal", "Mensal"])

with tab_diario:
    md = bulletin.boletim_diario()
    st.markdown(md)
    c1, c2, c3 = st.columns(3)
    if c1.button("Salvar Markdown", key="d_md"):
        p = bulletin.salvar_md(md, "diario")
        st.success(f"Salvo em {p}")
    if c2.button("Salvar DOCX", key="d_doc"):
        p = bulletin.salvar_docx(md, "diario")
        st.success(f"Salvo em {p}")
    if c3.button("Salvar PDF", key="d_pdf"):
        p = bulletin.salvar_pdf(md, "diario")
        st.success(f"Salvo em {p}")

with tab_sem:
    md = bulletin.boletim_semanal()
    st.markdown(md)
    c1, c2, c3 = st.columns(3)
    if c1.button("Salvar Markdown", key="s_md"):
        p = bulletin.salvar_md(md, "semanal")
        st.success(f"Salvo em {p}")
    if c2.button("Salvar DOCX", key="s_doc"):
        p = bulletin.salvar_docx(md, "semanal")
        st.success(f"Salvo em {p}")
    if c3.button("Salvar PDF", key="s_pdf"):
        p = bulletin.salvar_pdf(md, "semanal")
        st.success(f"Salvo em {p}")

with tab_mes:
    md = bulletin.boletim_mensal()
    st.markdown(md)
    c1, c2, c3 = st.columns(3)
    if c1.button("Salvar Markdown", key="m_md"):
        p = bulletin.salvar_md(md, "mensal")
        st.success(f"Salvo em {p}")
    if c2.button("Salvar DOCX", key="m_doc"):
        p = bulletin.salvar_docx(md, "mensal")
        st.success(f"Salvo em {p}")
    if c3.button("Salvar PDF", key="m_pdf"):
        p = bulletin.salvar_pdf(md, "mensal")
        st.success(f"Salvo em {p}")
