"""Estrategia de UID para deduplicacao."""
from __future__ import annotations

import hashlib
import re


def make_uid(pmid: str | None, doi: str | None, link: str | None, titulo: str | None) -> str:
    if pmid and pmid.strip():
        return f"pmid:{pmid.strip()}"
    if doi and doi.strip():
        return f"doi:{_normalize_doi(doi)}"
    if link and link.strip():
        return f"url:{link.strip()}"
    if titulo and titulo.strip():
        h = hashlib.sha1(titulo.strip().lower().encode("utf-8")).hexdigest()
        return f"sha1:{h}"
    return f"sha1:empty"


def _normalize_doi(doi: str) -> str:
    d = doi.strip().lower()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d)
    d = d.strip()
    return d
