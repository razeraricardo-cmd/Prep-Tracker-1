"""Resumo critico opcional via Claude. Off por padrao."""
from __future__ import annotations

import os

SYSTEM = """Voce e um infectologista que escreve resumos criticos curtos para boletins de educacao continuada.
Receba TITULO + ABSTRACT em ingles. Escreva em portugues brasileiro o seguinte:
- RESUMO EM 5 LINHAS (fatos do estudo, nada inventado)
- IMPACTO PRATICO em ate 3 linhas (o que muda ou nao na pratica)
- LIMITACOES em ate 2 linhas
- GRAU DE CONFIANCA: alto / moderado / baixo / muito baixo, com justificativa de 1 linha
Nao extrapole para populacoes nao estudadas. Se for preprint, comece o impacto pratico com 'ALERTA: preprint nao revisado por pares'.
Saida sem markdown extra. Apenas texto corrido nas secoes acima.
"""


def disponivel() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def resumir(titulo: str, abstract: str, preprint: bool, modelo: str = "claude-sonnet-4-6") -> str:
    if not disponivel():
        raise RuntimeError("ANTHROPIC_API_KEY ausente.")
    import anthropic

    client = anthropic.Anthropic()
    nota = " (PREPRINT)" if preprint else ""
    user = f"TITULO{nota}: {titulo}\n\nABSTRACT:\n{abstract or '(sem abstract)'}"
    msg = client.messages.create(
        model=modelo,
        max_tokens=900,
        system=SYSTEM,
        messages=[{"role": "user", "content": user}],
    )
    out = ""
    for block in msg.content:
        if getattr(block, "type", None) == "text":
            out += block.text
    return out.strip()
