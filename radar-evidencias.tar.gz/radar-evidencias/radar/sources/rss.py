"""Conector RSS / Atom generico."""
from __future__ import annotations

from typing import Any

import feedparser


def fetch_rss(url: str, fonte: str | None = None, tipo: str | None = None) -> list[dict[str, Any]]:
    parsed = feedparser.parse(url)
    out: list[dict[str, Any]] = []
    for entry in parsed.entries:
        link = entry.get("link", "")
        titulo = entry.get("title", "").strip()
        if not titulo:
            continue
        abstract = entry.get("summary", "") or entry.get("description", "") or ""
        autores = ", ".join((a.get("name") or "") for a in entry.get("authors", []) if a.get("name"))
        data_pub = ""
        if entry.get("published_parsed"):
            from time import strftime
            data_pub = strftime("%Y-%m-%d", entry.published_parsed)
        doi = ""
        for k in ("prism_doi", "dc_identifier"):
            if entry.get(k):
                doi = entry.get(k) or ""
                break

        out.append({
            "titulo": titulo,
            "abstract": abstract,
            "link": link,
            "autores": autores,
            "data_pub": data_pub or None,
            "doi": doi,
            "fonte": fonte or "rss",
            "tipo_fonte": tipo,
            "journal": parsed.feed.get("title", "") if parsed.feed else "",
            "publication_types": [],
        })
    return out
