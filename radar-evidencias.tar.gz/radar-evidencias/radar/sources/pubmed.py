"""Conector PubMed via NCBI E-utilities. Usa identificacao por email obrigatoria."""
from __future__ import annotations

import os
import time
from typing import Iterable
import xml.etree.ElementTree as ET

import requests

ESEARCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
EFETCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"


def _params_base() -> dict:
    p = {
        "db": "pubmed",
        "tool": os.environ.get("NCBI_TOOL", "RadarEvidenciasInfecto"),
        "email": os.environ.get("NCBI_EMAIL", "anon@example.com"),
    }
    key = os.environ.get("NCBI_API_KEY")
    if key:
        p["api_key"] = key
    return p


def search_pubmed(query: str, dias: int = 30, retmax: int = 50) -> list[str]:
    """Retorna lista de PMIDs."""
    params = _params_base() | {
        "term": f"{query} AND (\"last {dias} days\"[edat])",
        "retmax": retmax,
        "sort": "date",
        "retmode": "json",
    }
    r = requests.get(ESEARCH, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()
    return data.get("esearchresult", {}).get("idlist", []) or []


def fetch_pubmed(pmids: Iterable[str]) -> list[dict]:
    """Busca metadados de uma lista de PMIDs em lotes de ate 200."""
    pmids = [p for p in pmids if p]
    if not pmids:
        return []
    out: list[dict] = []
    for i in range(0, len(pmids), 200):
        lote = pmids[i:i + 200]
        params = _params_base() | {
            "id": ",".join(lote),
            "rettype": "abstract",
            "retmode": "xml",
        }
        r = requests.get(EFETCH, params=params, timeout=60)
        r.raise_for_status()
        out.extend(_parse_pubmed_xml(r.text))
        time.sleep(0.34 if "api_key" not in params else 0.11)  # rate limit
    return out


def _parse_pubmed_xml(xml_text: str) -> list[dict]:
    root = ET.fromstring(xml_text)
    artigos: list[dict] = []
    for art in root.findall(".//PubmedArticle"):
        pmid = (art.findtext(".//PMID") or "").strip()
        titulo = (art.findtext(".//ArticleTitle") or "").strip()
        abstract = " ".join(
            (a.text or "") for a in art.findall(".//Abstract/AbstractText")
        ).strip()
        journal = (art.findtext(".//Journal/ISOAbbreviation") or art.findtext(".//Journal/Title") or "").strip()
        ano = (art.findtext(".//JournalIssue/PubDate/Year") or art.findtext(".//JournalIssue/PubDate/MedlineDate") or "").strip()[:4]
        mes = (art.findtext(".//JournalIssue/PubDate/Month") or "").strip()
        dia = (art.findtext(".//JournalIssue/PubDate/Day") or "").strip()
        data_pub = "-".join([x for x in (ano, _mes_num(mes), dia) if x])
        autores: list[str] = []
        for au in art.findall(".//AuthorList/Author")[:6]:
            ln = au.findtext("LastName")
            init = au.findtext("Initials")
            if ln:
                autores.append(f"{ln} {init or ''}".strip())
        doi = ""
        for aid in art.findall(".//ArticleId"):
            if (aid.get("IdType") or "").lower() == "doi":
                doi = (aid.text or "").strip()
                break
        pub_types = [pt.text or "" for pt in art.findall(".//PublicationTypeList/PublicationType")]
        link = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else ""

        artigos.append({
            "pmid": pmid,
            "doi": doi,
            "titulo": titulo,
            "abstract": abstract,
            "journal": journal,
            "ano": ano,
            "data_pub": data_pub or None,
            "autores": ", ".join(autores),
            "publication_types": pub_types,
            "link": link,
            "fonte": "pubmed",
        })
    return artigos


_MESES = {
    "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "May": "05", "Jun": "06",
    "Jul": "07", "Aug": "08", "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12",
}


def _mes_num(m: str) -> str:
    if not m:
        return ""
    if m.isdigit():
        return m.zfill(2)
    return _MESES.get(m[:3].title(), "")
