"""Conector ClinicalTrials.gov (API v2)."""
from __future__ import annotations

import requests

API = "https://clinicaltrials.gov/api/v2/studies"


def search_trials(term: str, max_studies: int = 25) -> list[dict]:
    params = {
        "query.term": term,
        "pageSize": max_studies,
        "format": "json",
        "sort": "@relevance,LastUpdatePostDate:desc",
    }
    try:
        r = requests.get(API, params=params, timeout=30)
        r.raise_for_status()
    except requests.RequestException:
        return []
    data = r.json()
    out: list[dict] = []
    for s in data.get("studies", []):
        proto = s.get("protocolSection", {})
        ident = proto.get("identificationModule", {})
        status = proto.get("statusModule", {})
        nct = ident.get("nctId") or ""
        titulo = ident.get("briefTitle") or ident.get("officialTitle") or ""
        if not titulo:
            continue
        out.append({
            "pmid": "",
            "doi": "",
            "titulo": titulo,
            "abstract": proto.get("descriptionModule", {}).get("briefSummary", "") or "",
            "journal": "ClinicalTrials.gov",
            "ano": (status.get("lastUpdateSubmitDate") or "")[:4],
            "data_pub": status.get("lastUpdateSubmitDate") or "",
            "autores": "",
            "publication_types": ["Clinical Trial"],
            "link": f"https://clinicaltrials.gov/study/{nct}" if nct else "",
            "fonte": "clinicaltrials",
        })
    return out
