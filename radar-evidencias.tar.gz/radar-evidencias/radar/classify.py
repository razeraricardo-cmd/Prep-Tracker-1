"""Classificacao de tipo de evidencia e escore de prioridade."""
from __future__ import annotations

import re

from radar.config import scoring_cfg

# heuristicas simples por publication_type e por titulo/abstract.
RE_GUIDELINE = re.compile(r"\b(guideline|recommendation|consensus statement|practice statement)\b", re.IGNORECASE)
RE_SR_MA = re.compile(r"\b(systematic review|meta[\s-]?analysis)\b", re.IGNORECASE)
RE_RCT = re.compile(r"\b(randomi[sz]ed|randomi[sz]ed clinical trial|RCT)\b", re.IGNORECASE)
RE_COHORT = re.compile(r"\b(cohort)\b", re.IGNORECASE)
RE_CC = re.compile(r"\b(case[\s-]?control)\b", re.IGNORECASE)
RE_CASE_SERIES = re.compile(r"\b(case series|case report)\b", re.IGNORECASE)
RE_IN_VITRO = re.compile(r"\b(in vitro)\b", re.IGNORECASE)
RE_EDITORIAL = re.compile(r"\b(editorial|commentary|letter to the editor)\b", re.IGNORECASE)
RE_ANIMAL = re.compile(r"\b(mouse|murine|rat|rabbit|porcine|in vivo animal)\b", re.IGNORECASE)
RE_PRACTICE = re.compile(r"\b(practice[\s-]?changing|change practice|recommendation)\b", re.IGNORECASE)


def classify_evidence(titulo: str, abstract: str, publication_types: list[str] | None = None) -> str:
    pub = " ".join(publication_types or []).lower()
    blob = f"{titulo}\n{abstract}\n{pub}"
    if "guideline" in pub or RE_GUIDELINE.search(blob):
        return "Guideline"
    if "meta-analysis" in pub or "systematic review" in pub or RE_SR_MA.search(blob):
        return "Revisao sistematica / meta-analise"
    if "randomized controlled trial" in pub or RE_RCT.search(blob):
        return "Ensaio clinico randomizado"
    if "cohort" in pub or RE_COHORT.search(blob):
        return "Coorte"
    if RE_CC.search(blob):
        return "Caso-controle"
    if RE_CASE_SERIES.search(blob):
        return "Serie de casos"
    if RE_IN_VITRO.search(blob):
        return "In vitro"
    if "editorial" in pub or "comment" in pub or RE_EDITORIAL.search(blob):
        return "Editorial / Comentario"
    if RE_ANIMAL.search(blob):
        return "Estudo em animais"
    return "Observacional / nao classificado"


def score(article: dict, areas_keywords: dict[str, list[str]]) -> tuple[int, str | None, list[str]]:
    cfg = scoring_cfg()
    pesos = cfg.get("pesos", {})
    bonus_top = int(cfg.get("bonus_top", 0))
    bonus_kw = int(cfg.get("bonus_keyword", 0))
    bonus_pc = int(cfg.get("bonus_practice_changing", 0))
    top_journals = {j.lower() for j in cfg.get("bonus_journals_top", [])}

    tipo = (article.get("tipo_evidencia") or "").lower()
    base = 0
    if "guideline" in tipo:
        base = pesos.get("guideline", 0)
    elif "revisao" in tipo or "meta" in tipo:
        base = pesos.get("revisao_sistematica", 0)
    elif "ensaio" in tipo:
        base = pesos.get("ensaio_clinico", 0)
    elif "coorte" in tipo:
        base = pesos.get("coorte", 0)
    elif "caso-controle" in tipo:
        base = pesos.get("case_control", 0)
    elif "serie de casos" in tipo:
        base = pesos.get("serie_casos", 0)
    elif "in vitro" in tipo:
        base = pesos.get("in_vitro", 0)
    elif (article.get("fonte") or "").lower() == "preprint":
        base = pesos.get("preprint", 0)
    elif "editorial" in tipo:
        base = pesos.get("editorial", 0)
    elif "animais" in tipo:
        base = pesos.get("animal", 0)

    if (article.get("journal") or "").lower() in top_journals:
        base += bonus_top

    blob = f"{article.get('titulo','')}\n{article.get('abstract','')}".lower()
    if RE_PRACTICE.search(blob):
        base += bonus_pc

    melhor_area: str | None = None
    melhor_hits: list[str] = []
    melhor_qtd = 0
    for area_key, keywords in areas_keywords.items():
        hits = [k for k in keywords if k.lower() in blob]
        if len(hits) > melhor_qtd:
            melhor_qtd = len(hits)
            melhor_hits = hits
            melhor_area = area_key
    if melhor_qtd > 0:
        base += bonus_kw + min(10, melhor_qtd * 2)

    base = max(0, min(100, base))
    return base, melhor_area, melhor_hits
