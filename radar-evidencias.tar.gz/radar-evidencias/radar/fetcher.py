"""Orquestrador de busca: PubMed + RSS + ClinicalTrials + preprints."""
from __future__ import annotations

from typing import Iterable

from radar import config, db
from radar.classify import classify_evidence, score
from radar.dedup import make_uid
from radar.sources import clinicaltrials, pubmed, rss


def _areas_keywords() -> dict[str, list[str]]:
    return {k: v.get("palavras_chave", []) for k, v in config.areas().items()}


def run_pubmed(query: str, dias: int, retmax: int = 50) -> int:
    pmids = pubmed.search_pubmed(query, dias=dias, retmax=retmax)
    artigos = pubmed.fetch_pubmed(pmids)
    return _persist_batch(artigos)


def run_rss() -> int:
    total = 0
    for src in config.rss_sources():
        try:
            artigos = rss.fetch_rss(src["url"], fonte=src["nome"], tipo=src.get("tipo", "rss"))
        except Exception:
            continue
        total += _persist_batch(artigos)
    return total


def run_preprints() -> int:
    total = 0
    for src in config.preprints_rss():
        try:
            artigos = rss.fetch_rss(src["url"], fonte=src["nome"], tipo="preprint")
        except Exception:
            continue
        for a in artigos:
            a["fonte"] = "preprint"
        total += _persist_batch(artigos)
    return total


def run_clinicaltrials() -> int:
    total = 0
    for term in config.clinicaltrials_terms():
        artigos = clinicaltrials.search_trials(term)
        total += _persist_batch(artigos)
    return total


def run_all_areas(dias: int = 30, retmax_por_query: int = 25) -> dict:
    novos = 0
    queries = []
    for area_key, area in config.areas().items():
        for kw in area.get("palavras_chave", []):
            queries.append((area_key, kw))
            novos += run_pubmed(kw, dias=dias, retmax=retmax_por_query)
    rss_novos = run_rss()
    pre_novos = run_preprints()
    ct_novos = run_clinicaltrials()
    return {
        "pubmed_novos": novos,
        "rss_novos": rss_novos,
        "preprint_novos": pre_novos,
        "clinicaltrials_novos": ct_novos,
        "queries_executadas": len(queries),
    }


def _persist_batch(artigos: Iterable[dict]) -> int:
    kws = _areas_keywords()
    novos = 0
    for a in artigos:
        a["tipo_evidencia"] = classify_evidence(a.get("titulo", ""), a.get("abstract", ""), a.get("publication_types"))
        sc, area, hits = score(a, kws)
        a["score"] = sc
        a["area"] = area
        a["matched_keywords"] = hits
        a["uid"] = make_uid(a.get("pmid"), a.get("doi"), a.get("link"), a.get("titulo"))
        a.setdefault("status", "novo")
        if db.upsert_article(a):
            novos += 1
    return novos
