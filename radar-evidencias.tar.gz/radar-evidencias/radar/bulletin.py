"""Geracao de boletins diario / semanal / mensal."""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable

from jinja2 import Environment, FileSystemLoader

from radar import config, db

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"
EXPORT_DIR = Path(__file__).resolve().parent.parent / "boletins"


def _env() -> Environment:
    return Environment(
        loader=FileSystemLoader(TEMPLATE_DIR),
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )


def _resumo_curto(abstract: str | None) -> str:
    if not abstract:
        return "(sem abstract disponivel)"
    s = re.sub(r"\s+", " ", abstract).strip()
    return s[:500] + ("..." if len(s) > 500 else "")


def _parse_matched(s) -> list[str]:
    if not s:
        return []
    if isinstance(s, list):
        return s
    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        return []


def _render_artigos(artigos: Iterable[dict]) -> str:
    env = _env()
    tmpl = env.get_template("artigo.j2")
    blocos: list[str] = []
    for a in artigos:
        a = {**a, "matched_keywords": _parse_matched(a.get("matched_keywords"))}
        blocos.append(tmpl.render(a=a, resumo_curto=_resumo_curto(a.get("abstract"))))
    return "\n".join(blocos)


def boletim_diario() -> str:
    cfg = config.boletins_cfg()
    limiar = int(config.scoring_cfg().get("limiar_alerta", 60))
    n = int(cfg.get("max_diario", 5))
    hoje = date.today()
    desde = (hoje - timedelta(days=1)).isoformat()
    artigos = db.list_articles(score_min=limiar, desde=desde, limit=n)
    if not artigos:
        return f"# Boletim diario - {hoje.isoformat()}\n\nNenhum item acima do limiar {limiar}/100 nas ultimas 24h.\n"
    return (
        f"# Boletim diario - {hoje.isoformat()}\n\n"
        f"Top {len(artigos)} itens com prioridade >= {limiar}/100.\n\n"
        + _render_artigos(artigos)
    )


def boletim_semanal() -> str:
    cfg = config.boletins_cfg()
    n_por_area = int(cfg.get("max_semanal_por_area", 10))
    desde = (date.today() - timedelta(days=7)).isoformat()
    areas = config.areas()
    out = [f"# Boletim semanal - {date.today().isoformat()}\n"]
    for key, area in areas.items():
        artigos = db.list_articles(area=key, desde=desde, limit=n_por_area)
        if not artigos:
            continue
        out.append(f"\n## {area.get('nome', key)}\n")
        out.append(_render_artigos(artigos))
    sem_area = [a for a in db.list_articles(desde=desde, limit=200) if not a.get("area")]
    if sem_area:
        out.append("\n## Sem area classificada\n")
        out.append(_render_artigos(sem_area[:n_por_area]))
    if len(out) == 1:
        out.append("\nNenhum artigo na ultima semana.\n")
    return "\n".join(out)


def boletim_mensal() -> str:
    cfg = config.boletins_cfg()
    n = int(cfg.get("max_mensal_top", 10))
    desde = (date.today() - timedelta(days=30)).isoformat()
    artigos = db.list_articles(desde=desde, limit=n)
    if not artigos:
        return f"# Boletim mensal - {date.today().isoformat()}\n\nNenhum item.\n"
    return (
        f"# Boletim mensal - {date.today().isoformat()}\n\n"
        f"Top {len(artigos)} evidencias do mes.\n\n"
        + _render_artigos(artigos)
    )


def garantir_export_dir() -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    return EXPORT_DIR


def salvar_md(conteudo: str, tipo: str) -> Path:
    pasta = garantir_export_dir()
    nome = f"boletim-{tipo}-{date.today().isoformat()}.md"
    p = pasta / nome
    p.write_text(conteudo, encoding="utf-8")
    db.register_bulletin(tipo, datetime.now().isoformat(timespec="minutes"), str(p))
    return p


def salvar_docx(conteudo: str, tipo: str) -> Path:
    from docx import Document
    pasta = garantir_export_dir()
    doc = Document()
    for linha in conteudo.splitlines():
        if linha.startswith("# "):
            doc.add_heading(linha[2:], level=1)
        elif linha.startswith("## "):
            doc.add_heading(linha[3:], level=2)
        elif linha.startswith("### "):
            doc.add_heading(linha[4:], level=3)
        elif linha.startswith("- "):
            doc.add_paragraph(linha[2:], style="List Bullet")
        else:
            doc.add_paragraph(linha)
    nome = f"boletim-{tipo}-{date.today().isoformat()}.docx"
    p = pasta / nome
    doc.save(str(p))
    db.register_bulletin(tipo, datetime.now().isoformat(timespec="minutes"), str(p))
    return p


def salvar_pdf(conteudo: str, tipo: str) -> Path:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    pasta = garantir_export_dir()
    nome = f"boletim-{tipo}-{date.today().isoformat()}.pdf"
    p = pasta / nome
    styles = getSampleStyleSheet()
    flow = []
    for linha in conteudo.splitlines():
        if not linha.strip():
            flow.append(Spacer(1, 6))
            continue
        if linha.startswith("# "):
            flow.append(Paragraph(linha[2:], styles["Heading1"]))
        elif linha.startswith("## "):
            flow.append(Paragraph(linha[3:], styles["Heading2"]))
        elif linha.startswith("### "):
            flow.append(Paragraph(linha[4:], styles["Heading3"]))
        else:
            safe = linha.replace("<", "&lt;").replace(">", "&gt;")
            flow.append(Paragraph(safe, styles["BodyText"]))
    SimpleDocTemplate(str(p), pagesize=A4).build(flow)
    db.register_bulletin(tipo, datetime.now().isoformat(timespec="minutes"), str(p))
    return p
