"""Export auxiliar para XLSX/BibTeX/RIS dos artigos."""
from __future__ import annotations

from io import BytesIO

import pandas as pd

from radar import db


def to_xlsx(articles: list[dict]) -> bytes:
    df = pd.DataFrame(articles)
    if df.empty:
        df = pd.DataFrame(columns=["uid", "titulo"])
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="artigos", index=False)
    return buf.getvalue()


def to_bibtex(articles: list[dict]) -> str:
    out: list[str] = []
    for a in articles:
        key = a.get("uid", "ref").replace(":", "_").replace("/", "_").replace(".", "_")
        out.append(
            "@article{" + key + ",\n" +
            f"  title = {{{a.get('titulo', '')}}},\n" +
            (f"  author = {{{a.get('autores', '')}}},\n" if a.get("autores") else "") +
            (f"  journal = {{{a.get('journal', '')}}},\n" if a.get("journal") else "") +
            (f"  year = {{{a.get('ano', '')}}},\n" if a.get("ano") else "") +
            (f"  doi = {{{a.get('doi', '')}}},\n" if a.get("doi") else "") +
            (f"  url = {{{a.get('link', '')}}},\n" if a.get("link") else "") +
            "}\n"
        )
    return "\n".join(out)


def to_ris(articles: list[dict]) -> str:
    out: list[str] = []
    for a in articles:
        out.append("TY  - JOUR")
        if a.get("titulo"):
            out.append(f"TI  - {a['titulo']}")
        for au in (a.get("autores") or "").split(", "):
            if au.strip():
                out.append(f"AU  - {au.strip()}")
        if a.get("journal"):
            out.append(f"JO  - {a['journal']}")
        if a.get("ano"):
            out.append(f"PY  - {a['ano']}")
        if a.get("doi"):
            out.append(f"DO  - {a['doi']}")
        if a.get("link"):
            out.append(f"UR  - {a['link']}")
        if a.get("abstract"):
            out.append(f"AB  - {a['abstract']}")
        out.append("ER  - ")
        out.append("")
    return "\n".join(out)
