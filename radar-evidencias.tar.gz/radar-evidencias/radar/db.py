"""SQLite schema e operacoes para o Radar."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator, Any

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "radar.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL UNIQUE,
  tipo TEXT NOT NULL,             -- pubmed | rss | clinicaltrials | preprint
  url TEXT,
  ativo INTEGER NOT NULL DEFAULT 1,
  ultima_busca TEXT
);

CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT NOT NULL UNIQUE,        -- pmid:1234 | doi:10.x | url:...
  pmid TEXT,
  doi TEXT,
  titulo TEXT NOT NULL,
  autores TEXT,
  journal TEXT,
  ano TEXT,
  data_pub TEXT,
  abstract TEXT,
  tipo_evidencia TEXT,
  link TEXT,
  fonte TEXT,
  area TEXT,
  matched_keywords TEXT,
  score INTEGER DEFAULT 0,
  status TEXT DEFAULT 'novo',      -- novo | relevante | lido | ignorado | salvo | practice | apresentar
  observacoes TEXT,
  resumo_critico TEXT,
  criado_em TEXT NOT NULL,
  atualizado_em TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_art_score ON articles(score DESC);
CREATE INDEX IF NOT EXISTS idx_art_area ON articles(area);
CREATE INDEX IF NOT EXISTS idx_art_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_art_data ON articles(data_pub);

CREATE TABLE IF NOT EXISTS bulletins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo TEXT NOT NULL,              -- diario | semanal | mensal
  periodo TEXT NOT NULL,
  caminho TEXT NOT NULL,
  criado_em TEXT NOT NULL
);
"""


def db_path() -> Path:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return DB_PATH


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def upsert_article(a: dict) -> bool:
    """Insere se uid nao existe; retorna True se foi novidade."""
    a = {**a}
    a["matched_keywords"] = (
        json.dumps(a["matched_keywords"], ensure_ascii=False)
        if isinstance(a.get("matched_keywords"), list)
        else a.get("matched_keywords")
    )
    a.setdefault("criado_em", _now())
    a["atualizado_em"] = _now()

    cols = [
        "uid", "pmid", "doi", "titulo", "autores", "journal", "ano",
        "data_pub", "abstract", "tipo_evidencia", "link", "fonte", "area",
        "matched_keywords", "score", "status", "criado_em", "atualizado_em",
    ]
    valores = [a.get(c) for c in cols]

    with connect() as conn:
        try:
            cur = conn.execute(
                f"INSERT INTO articles ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                valores,
            )
            return cur.rowcount > 0
        except sqlite3.IntegrityError:
            # ja existe; atualiza score/area/matched_keywords se mudaram
            conn.execute(
                "UPDATE articles SET score=?, area=?, matched_keywords=?, atualizado_em=? WHERE uid=?",
                (a.get("score"), a.get("area"), a.get("matched_keywords"), _now(), a["uid"]),
            )
            return False


def list_articles(
    status: str | None = None,
    area: str | None = None,
    score_min: int | None = None,
    desde: str | None = None,
    limit: int = 500,
) -> list[dict]:
    sql = "SELECT * FROM articles WHERE 1=1"
    params: list[Any] = []
    if status:
        sql += " AND status = ?"
        params.append(status)
    if area:
        sql += " AND area = ?"
        params.append(area)
    if score_min is not None:
        sql += " AND score >= ?"
        params.append(score_min)
    if desde:
        sql += " AND data_pub >= ?"
        params.append(desde)
    sql += " ORDER BY score DESC, data_pub DESC LIMIT ?"
    params.append(limit)
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def get_article(article_id: int) -> dict | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM articles WHERE id = ?", (article_id,)).fetchone()
    return dict(row) if row else None


def update_article(article_id: int, fields: dict) -> None:
    fields = {k: v for k, v in fields.items() if k not in {"id", "uid", "criado_em"}}
    fields["atualizado_em"] = _now()
    sets = ", ".join(f"{k} = ?" for k in fields)
    with connect() as conn:
        conn.execute(f"UPDATE articles SET {sets} WHERE id = ?", (*fields.values(), article_id))


def delete_article(article_id: int) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM articles WHERE id = ?", (article_id,))


def article_count_by_status() -> dict[str, int]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT status, COUNT(*) c FROM articles GROUP BY status"
        ).fetchall()
    return {r["status"]: r["c"] for r in rows}


def register_bulletin(tipo: str, periodo: str, caminho: str) -> int:
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO bulletins (tipo, periodo, caminho, criado_em) VALUES (?, ?, ?, ?)",
            (tipo, periodo, caminho, _now()),
        )
        return cur.lastrowid
