"""Carrega config.yaml."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"


@lru_cache(maxsize=1)
def load() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    return yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}


def areas() -> dict:
    return load().get("areas", {})


def rss_sources() -> list[dict]:
    return load().get("rss_sources", [])


def journals_pubmed() -> list[str]:
    return load().get("journals_pubmed", [])


def preprints_rss() -> list[dict]:
    return load().get("preprints_rss", [])


def clinicaltrials_terms() -> list[str]:
    return load().get("clinicaltrials_terms", [])


def scoring_cfg() -> dict:
    return load().get("scoring", {})


def boletins_cfg() -> dict:
    return load().get("boletins", {})


def geral() -> dict:
    return load().get("geral", {})
