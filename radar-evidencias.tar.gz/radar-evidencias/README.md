# Radar de Evidencias - Infectologia

Aplicacao local que busca novidades cientificas em PubMed, RSS de journals e sociedades,
ClinicalTrials.gov e preprints (medRxiv/bioRxiv); deduplica, classifica por tipo de evidencia,
prontua um escore de prioridade clinica e gera boletins prontos para leitura.

Pergunta central: **o que saiu de novo que pode mudar ou refinar minha pratica em
infectologia, ortoinfectologia, OPAT/PAD, antimicrobianos e imunocomprometidos?**

**Nao substitui leitura critica.** Resumos heuristicos ou via IA nao validam metodologia.

## Recursos

- Conector PubMed via NCBI E-utilities (com `NCBI_EMAIL` obrigatorio)
- Conector RSS / Atom generico para journals + sociedades
- Conector ClinicalTrials.gov v2 para ensaios
- Conector preprints (medRxiv/bioRxiv) com flag automatica
- Deduplicacao por PMID/DOI/URL/hash do titulo
- Classificacao heuristica de tipo de evidencia (guideline, RCT, revisao sistematica, coorte, preprint, etc.)
- Escore de prioridade 0-100 que considera tipo de estudo, journal top, palavras-chave da sua area e linguagem "practice changing"
- Marcacao por status: novo, relevante, lido, ignorado, salvo, practice, apresentar
- Boletins diario / semanal / mensal em Markdown / DOCX / PDF
- Export XLSX + BibTeX + RIS
- Resumo critico opcional via Claude (off por padrao)
- Banco SQLite local em `data/radar.db`

## Privacidade

- 100% local. Banco SQLite. Boletins em `boletins/`.
- Nenhum dado de paciente. Apenas metadados publicos (PMID, DOI, abstract).
- Resumo critico via IA so dispara com `ANTHROPIC_API_KEY` configurada e marcacao explicita na UI.

## Instalacao

```sh
git clone https://github.com/SEU-USUARIO/radar-evidencias
cd radar-evidencias
cp .env.example .env       # edite NCBI_EMAIL obrigatorio
chmod +x run.sh
./run.sh
```

Abre em http://localhost:8501.

Manualmente:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Configuracao

Edite `config.yaml` (tambem editavel pela UI em **Configuracoes**):

- `areas` - keywords por area (ortoinfecto, antimicrobianos, bacteremias, HIV/imuno, ITU, GI, OPAT)
- `rss_sources` - feeds a monitorar
- `journals_pubmed` - lista usada para queries direcionadas (extensivel)
- `clinicaltrials_terms` - termos para ensaios
- `preprints_rss` - feeds de preprint
- `scoring` - pesos do escore
- `boletins` - quantos itens em cada boletim
- `geral` - frequencia de busca, janela em dias

## Politica de uso

- PubMed E-utilities exige identificacao por email (`NCBI_EMAIL`). Sem isso, o NCBI bloqueia.
- API key NCBI eleva o rate limit para 10 req/s (opcional).
- Nao fazemos scraping de paywall. Quando texto completo nao esta disponivel, trabalhamos apenas com titulo + abstract + metadados.

## Agendamento (cron)

Para rodar busca periodicamente sem abrir o Streamlit, crie um cronjob:

```cron
*/360 * * * * cd /caminho/radar-evidencias && .venv/bin/python -c "from radar import fetcher; print(fetcher.run_all_areas())" >> data/fetch.log 2>&1
```

## Testes

```sh
pytest -q
```

## Gaps conhecidos (MVP)

- A classificacao de tipo de evidencia e heuristica (regex + publication_types). Nao substitui MeSH terms.
- O escore e linear, sem ajuste fino por tamanho de amostra (so quando informado no abstract).
- Resumo critico em portugues so via Claude API. Sem chave, mostra o resumo heuristico (500 chars do abstract).
- Sem alerta push automatico. Use cron + leitura do diretorio `boletins/`.

## Aviso clinico

- O sistema **nao indica conduta**.
- Sinaliza alta prioridade, nao "verdade".
- Preprints sao marcados explicitamente.
- Sempre cite a fonte original ao mudar conduta.
