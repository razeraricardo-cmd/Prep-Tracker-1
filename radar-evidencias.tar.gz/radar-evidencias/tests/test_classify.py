from radar.classify import classify_evidence, score


def test_classifica_guideline():
    assert classify_evidence("IDSA guideline for X", "...", ["Guideline"]) == "Guideline"


def test_classifica_meta_analise():
    t = "Systematic review and meta-analysis of duration in gram-negative bacteremia"
    assert "meta" in classify_evidence(t, "", []).lower() or "Revisao" in classify_evidence(t, "", [])


def test_score_guideline_recebe_peso_alto():
    artigo = {
        "titulo": "IDSA practice guideline on PJI",
        "abstract": "Recommendations for prosthetic joint infection",
        "tipo_evidencia": "Guideline",
        "journal": "Clin Infect Dis",
        "fonte": "pubmed",
    }
    kws = {"ortoinfecto": ["prosthetic joint infection", "DAIR"]}
    sc, area, hits = score(artigo, kws)
    assert sc >= 50
    assert area == "ortoinfecto"
    assert "prosthetic joint infection" in hits
