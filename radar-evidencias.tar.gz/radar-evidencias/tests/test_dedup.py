from radar.dedup import make_uid


def test_uid_prefere_pmid():
    assert make_uid("123", "10.1/abc", "http://x", "Titulo") == "pmid:123"


def test_uid_fallback_para_doi():
    assert make_uid(None, "10.1/abc", "http://x", "Titulo") == "doi:10.1/abc"


def test_uid_normaliza_doi_com_url():
    assert make_uid("", "https://doi.org/10.1/Abc", None, None) == "doi:10.1/abc"


def test_uid_fallback_titulo_estavel():
    a = make_uid(None, None, None, "Titulo Mesmo")
    b = make_uid(None, None, None, "Titulo Mesmo")
    assert a == b and a.startswith("sha1:")
