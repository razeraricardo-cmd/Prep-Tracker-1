import json

from radar import bulletin


def test_resumo_curto_trunca():
    longo = "a" * 600
    s = bulletin._resumo_curto(longo)
    assert len(s) <= 503  # 500 + "..."
    assert s.endswith("...")


def test_parse_matched_aceita_json_e_lista():
    assert bulletin._parse_matched(None) == []
    assert bulletin._parse_matched("") == []
    assert bulletin._parse_matched(json.dumps(["a", "b"])) == ["a", "b"]
    assert bulletin._parse_matched(["c"]) == ["c"]
